-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : lun. 24 oct. 2022 à 10:45
-- Version du serveur : 8.0.27
-- Version de PHP : 8.1.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `abdou`
--
CREATE DATABASE IF NOT EXISTS `abdou` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `abdou`;

-- --------------------------------------------------------

--
-- Structure de la table `courriers`
--

DROP TABLE IF EXISTS `courriers`;
CREATE TABLE IF NOT EXISTS `courriers` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `courrier_libele` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `courrier_date_arrive` date NOT NULL,
  `courrier_status` enum('enStok','enCours','destoke') COLLATE utf8mb4_unicode_ci NOT NULL,
  `emeteur_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `emplacement_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `courriers_emeteur_id_foreign` (`emeteur_id`),
  KEY `courriers_user_id_foreign` (`user_id`),
  KEY `courriers_emplacement_id_foreign` (`emplacement_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `courriers`
--

INSERT INTO `courriers` (`id`, `courrier_libele`, `courrier_date_arrive`, `courrier_status`, `emeteur_id`, `user_id`, `emplacement_id`, `created_at`, `updated_at`) VALUES
(1, 'telephone', '2022-08-17', 'enStok', 1, 1, 1, '2022-08-16 06:06:48', '2022-08-16 06:06:48');

-- --------------------------------------------------------

--
-- Structure de la table `destinataires`
--

DROP TABLE IF EXISTS `destinataires`;
CREATE TABLE IF NOT EXISTS `destinataires` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `destinataire_noms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `destinataire_prenoms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `destinataire_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `destinataire_telephone` int NOT NULL,
  `destinataire_pasword` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `emeteurs`
--

DROP TABLE IF EXISTS `emeteurs`;
CREATE TABLE IF NOT EXISTS `emeteurs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `emeteur_noms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `emeteurs`
--

INSERT INTO `emeteurs` (`id`, `emeteur_noms`, `created_at`, `updated_at`) VALUES
(1, 'dubel', '2022-08-16 06:05:06', '2022-08-16 06:05:06');

-- --------------------------------------------------------

--
-- Structure de la table `emplacements`
--

DROP TABLE IF EXISTS `emplacements`;
CREATE TABLE IF NOT EXISTS `emplacements` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `emplacement_noms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emplacement_detail` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `emplacements`
--

INSERT INTO `emplacements` (`id`, `emplacement_noms`, `emplacement_detail`, `created_at`, `updated_at`) VALUES
(1, 'caisse3', 'lhhnbvfyfyftftftggfhjjj', '2022-08-16 06:05:45', '2022-08-16 06:05:45');

-- --------------------------------------------------------

--
-- Structure de la table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `historiques`
--

DROP TABLE IF EXISTS `historiques`;
CREATE TABLE IF NOT EXISTS `historiques` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `poste_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `historiques_poste_id_foreign` (`poste_id`),
  KEY `historiques_user_id_foreign` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `historiques`
--

INSERT INTO `historiques` (`id`, `poste_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2022-08-14 23:25:00', '2022-08-14 23:25:00'),
(2, 2, 2, '2022-08-14 23:30:51', '2022-08-14 23:30:51'),
(3, 3, 3, '2022-08-14 23:31:22', '2022-08-14 23:31:22'),
(4, 4, 4, '2022-08-14 23:31:55', '2022-08-14 23:31:55'),
(5, 5, 5, '2022-08-16 07:29:59', '2022-08-16 07:29:59'),
(6, 6, 6, '2022-08-16 07:52:26', '2022-08-16 07:52:26'),
(7, 7, 7, '2022-08-16 07:59:33', '2022-08-16 07:59:33'),
(8, 8, 8, '2022-08-21 19:26:15', '2022-08-21 19:26:15'),
(9, 9, 9, '2022-08-22 12:01:31', '2022-08-22 12:01:31');

-- --------------------------------------------------------

--
-- Structure de la table `images`
--

DROP TABLE IF EXISTS `images`;
CREATE TABLE IF NOT EXISTS `images` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `images` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `images`
--

INSERT INTO `images` (`id`, `images`, `created_at`, `updated_at`) VALUES
(1, 'posts/yolfKVDijyyS5teehfF1fqU6tlnZeIleAwJiMVsi.jpg', '2022-08-14 23:30:19', '2022-08-14 23:30:19'),
(2, 'posts/h8rtxBWD5r2uHiil1dmpDuALLQNRObWLLyE0ezTf.jpg', '2022-08-16 07:19:35', '2022-08-16 07:19:35'),
(3, 'posts/gBTkgoWW54vQfpCCCgBZDx8udtiUNFszDcB6TkhS.jpg', '2022-08-16 07:24:55', '2022-08-16 07:24:55'),
(4, 'posts/5MFUZsjZNgrVI2fL9Dn7kNIcrar8tbyP1sQtx6Xn.jpg', '2022-08-16 07:25:08', '2022-08-16 07:25:08'),
(5, 'posts/lO7BNJ60e6cEikI1J2VyqBGQFGlPKEleMqaBGq8X.jpg', '2022-08-16 07:49:52', '2022-08-16 07:49:52'),
(6, 'posts/hSO3khoXB4W01JpRICxoa0aTSDqW6ZeH45y6YOqs.jpg', '2022-08-16 07:52:43', '2022-08-16 07:52:43'),
(7, 'posts/mgwrmV3IywZZvZGDOE4ZHjbqtqVrrR2sRzmypIRT.jpg', '2022-08-16 07:59:51', '2022-08-16 07:59:51'),
(8, 'posts/v3w8DCcyHJ0nBTYWeYU03z85eDYHE3FsgZoF7DaU.jpg', '2022-08-21 19:26:51', '2022-08-21 19:26:51');

-- --------------------------------------------------------

--
-- Structure de la table `message`
--

DROP TABLE IF EXISTS `message`;
CREATE TABLE IF NOT EXISTS `message` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2022_06_16_105357_create_receptionistes_table', 1),
(5, '2022_06_16_114634_create_emplacements_table', 1),
(6, '2022_06_16_115737_create_destinataires_table', 1),
(7, '2022_06_16_121946_create_postes_table', 1),
(8, '2022_06_16_130707_create_historiques_table', 1),
(9, '2022_06_16_132853_create_emeteurs_table', 1),
(10, '2022_06_16_133129_create_courriers_table', 1),
(11, '2022_06_20_105740_create_roles_table', 1),
(12, '2022_06_24_082540_create_messages_table', 1),
(13, '2022_07_05_133006_create_notifications_table', 1),
(14, '2022_07_17_153444_create_images_table', 1);

-- --------------------------------------------------------

--
-- Structure de la table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint UNSIGNED NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `postes`
--

DROP TABLE IF EXISTS `postes`;
CREATE TABLE IF NOT EXISTS `postes` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `poste_libele` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `postes_id_unique` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `postes`
--

INSERT INTO `postes` (`id`, `poste_libele`, `created_at`, `updated_at`) VALUES
(1, 'pdg', '2022-08-14 23:25:00', '2022-08-14 23:25:00'),
(2, 'sg', '2022-08-14 23:30:51', '2022-08-14 23:30:51'),
(3, 'gh', '2022-08-14 23:31:22', '2022-08-14 23:31:22'),
(4, 'sg', '2022-08-14 23:31:55', '2022-08-14 23:31:55'),
(5, 'pdg', '2022-08-16 07:29:59', '2022-08-16 07:29:59'),
(6, 'pdg', '2022-08-16 07:52:26', '2022-08-16 07:52:26'),
(7, 'pdg', '2022-08-16 07:59:33', '2022-08-16 07:59:33'),
(8, 'pdg', '2022-08-21 19:26:15', '2022-08-21 19:26:15'),
(9, 'pdg', '2022-08-22 12:01:32', '2022-08-22 12:01:32');

-- --------------------------------------------------------

--
-- Structure de la table `receptionistes`
--

DROP TABLE IF EXISTS `receptionistes`;
CREATE TABLE IF NOT EXISTS `receptionistes` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `receptioniste_noms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receptioniste_prenoms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receptioniste_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receptioniste_password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_id` bigint UNSIGNED DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_type` enum('admin','user') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `age` tinyint NOT NULL DEFAULT '1',
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `utype` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT 'ADM for Admin and USR for user or Customer',
  `number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ZIP` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `role_id` bigint UNSIGNED NOT NULL DEFAULT '1',
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT 'status',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_remember_token_unique` (`remember_token`),
  KEY `users_image_id_foreign` (`image_id`),
  KEY `users_role_id_foreign` (`role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `gender`, `email`, `image_id`, `password`, `user_type`, `age`, `address`, `utype`, `number`, `city`, `ZIP`, `email_verified_at`, `role_id`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES
(9, 'abdou', 'gg', NULL, 'njutapmvouiabdouchirac@gmail.com', NULL, '$2y$10$bVDRAAhpnhDSUBdR8s7TLeUt6Jp5YaikX5sPeryxlwihx3yu7JXym', 'user', 1, NULL, '1', NULL, NULL, NULL, NULL, 1, '1', NULL, '2022-08-22 12:01:31', '2022-08-22 12:01:31'),
(8, 'abdou', 'maeva', NULL, 'malick@gmail.com', 8, '$2y$10$LgXBvn47Oxo4BETrP2MMuO3st.2XIp/QG1RY2fbT.bJAU.pC7QFlK', 'user', 1, NULL, '1', NULL, NULL, NULL, NULL, 1, '1', NULL, '2022-08-21 19:26:15', '2022-08-21 19:26:51'),
(4, 'njoya', 'mama', NULL, 'maeva@gmail.com', NULL, '$2y$10$Pv/OGDxqUOB.EyUZOUp1/ebOyVan16aJURL5ueZcN1j1jWEXc7BGe', 'user', 1, NULL, '1', NULL, NULL, NULL, NULL, 1, '1', NULL, '2022-08-14 23:31:55', '2022-08-14 23:31:55'),
(5, 'j', 'g', NULL, 'demo@getcraftable.com', 5, '$2y$10$/Q9VlCjV3yHDCap9H8/J3uajsl.WOl3CQI1Qwm9jHUlUkox9Q8SHm', 'user', 1, NULL, '1', NULL, NULL, NULL, NULL, 1, '1', NULL, '2022-08-16 07:29:59', '2022-08-16 07:49:52'),
(6, 'b', 'j', NULL, 'njutapmvotuiabdouchirac@gmail.com', 6, '$2y$10$k5HtkOxfqGS.hP1SI03EtOqVIK5wmaFMiBV7xrvZzKjYxCA0e9D1m', 'user', 1, NULL, '1', NULL, NULL, NULL, NULL, 1, '1', NULL, '2022-08-16 07:52:26', '2022-08-16 07:52:43'),
(7, 'abdou', 'chirac', NULL, 'njutapmvghouiabdouchirac@gmail.com', 7, '$2y$10$9yNgiqD.g4Ilur4dY5A4me.whcgqVbE7h454eW6wkjPzRwjsxK1SW', 'user', 1, NULL, '1', NULL, NULL, NULL, NULL, 1, '1', NULL, '2022-08-16 07:59:33', '2022-08-16 07:59:51');
--
-- Base de données : `bloc`
--
CREATE DATABASE IF NOT EXISTS `bloc` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `bloc`;

-- --------------------------------------------------------

--
-- Structure de la table `courriers`
--

DROP TABLE IF EXISTS `courriers`;
CREATE TABLE IF NOT EXISTS `courriers` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `courrier_libele` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `courrier_date_arrive` date NOT NULL,
  `courrier_status` enum('enStok','enCours','destoke') COLLATE utf8mb4_unicode_ci NOT NULL,
  `emeteur_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `emplacement_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `courriers_emeteur_id_foreign` (`emeteur_id`),
  KEY `courriers_user_id_foreign` (`user_id`),
  KEY `courriers_emplacement_id_foreign` (`emplacement_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `destinataires`
--

DROP TABLE IF EXISTS `destinataires`;
CREATE TABLE IF NOT EXISTS `destinataires` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `destinataire_noms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `destinataire_prenoms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `destinataire_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `destinataire_telephone` int NOT NULL,
  `destinataire_pasword` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `emeteurs`
--

DROP TABLE IF EXISTS `emeteurs`;
CREATE TABLE IF NOT EXISTS `emeteurs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `emeteur_noms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `emplacements`
--

DROP TABLE IF EXISTS `emplacements`;
CREATE TABLE IF NOT EXISTS `emplacements` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `emplacement_noms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emplacement_detail` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `historiques`
--

DROP TABLE IF EXISTS `historiques`;
CREATE TABLE IF NOT EXISTS `historiques` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `poste_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `historiques_poste_id_foreign` (`poste_id`),
  KEY `historiques_user_id_foreign` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `historiques`
--

INSERT INTO `historiques` (`id`, `poste_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2022-09-20 14:37:47', '2022-09-20 14:37:47');

-- --------------------------------------------------------

--
-- Structure de la table `images`
--

DROP TABLE IF EXISTS `images`;
CREATE TABLE IF NOT EXISTS `images` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `images` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `message`
--

DROP TABLE IF EXISTS `message`;
CREATE TABLE IF NOT EXISTS `message` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2022_06_16_105357_create_receptionistes_table', 1),
(5, '2022_06_16_114634_create_emplacements_table', 1),
(6, '2022_06_16_115737_create_destinataires_table', 1),
(7, '2022_06_16_121946_create_postes_table', 1),
(8, '2022_06_16_130707_create_historiques_table', 1),
(9, '2022_06_16_132853_create_emeteurs_table', 1),
(10, '2022_06_16_133129_create_courriers_table', 1),
(11, '2022_06_20_105740_create_roles_table', 1),
(12, '2022_06_24_082540_create_messages_table', 1),
(13, '2022_07_05_133006_create_notifications_table', 1),
(14, '2022_07_17_153444_create_images_table', 1);

-- --------------------------------------------------------

--
-- Structure de la table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint UNSIGNED NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `postes`
--

DROP TABLE IF EXISTS `postes`;
CREATE TABLE IF NOT EXISTS `postes` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `poste_libele` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `postes_id_unique` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `postes`
--

INSERT INTO `postes` (`id`, `poste_libele`, `created_at`, `updated_at`) VALUES
(1, 'pdg', '2022-09-20 14:37:47', '2022-09-20 14:37:47');

-- --------------------------------------------------------

--
-- Structure de la table `receptionistes`
--

DROP TABLE IF EXISTS `receptionistes`;
CREATE TABLE IF NOT EXISTS `receptionistes` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `receptioniste_noms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receptioniste_prenoms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receptioniste_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receptioniste_password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_id` bigint UNSIGNED DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_type` enum('admin','user') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `age` tinyint NOT NULL DEFAULT '1',
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `utype` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT 'ADM for Admin and USR for user or Customer',
  `number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ZIP` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `role_id` bigint UNSIGNED NOT NULL DEFAULT '1',
  `status` enum('actif','inactif') COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_remember_token_unique` (`remember_token`),
  KEY `users_image_id_foreign` (`image_id`),
  KEY `users_role_id_foreign` (`role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `gender`, `email`, `image_id`, `password`, `user_type`, `age`, `address`, `utype`, `number`, `city`, `ZIP`, `email_verified_at`, `role_id`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'abdou', 'maeva', NULL, 'njutapmvouiabdouchirac@gmail.com', NULL, '$2y$10$7C5dKJ5k7/GqyLCUPeKX5.l4hBmI6wu2KxoPFEBCRINfFp7VweLvq', 'user', 1, NULL, '1', NULL, NULL, NULL, NULL, 1, 'actif', NULL, '2022-09-20 14:37:47', '2022-09-20 14:37:47');
--
-- Base de données : `chirac`
--
CREATE DATABASE IF NOT EXISTS `chirac` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `chirac`;

-- --------------------------------------------------------

--
-- Structure de la table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1);

-- --------------------------------------------------------

--
-- Structure de la table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_seen` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
--
-- Base de données : `crud`
--
CREATE DATABASE IF NOT EXISTS `crud` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `crud`;

-- --------------------------------------------------------

--
-- Structure de la table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `items`
--

DROP TABLE IF EXISTS `items`;
CREATE TABLE IF NOT EXISTS `items` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double(8,2) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `items_user_id_index` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2022_07_21_154128_create_items_table', 2);

-- --------------------------------------------------------

--
-- Structure de la table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_type` enum('admin','user') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `age` tinyint NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `user_type`, `age`, `address`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Hannah Olson', 'dickens.friedrich@example.com', 'user', 21, '56795 Paige Ramp\nNorth Elvisport, DE 79617-9453', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'qNGJ5ZFRTD', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(2, 'Eddie Howe II', 'rconroy@example.com', 'user', 40, '3250 Maud Estates\nNew Wendyfurt, NE 34960', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'BsL4LTUWoU', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(3, 'Tyrese Weimann', 'jacobson.isidro@example.org', 'user', 43, '995 Cortez Row Suite 804\nWest Marjorieport, IL 04401', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '4YUmKPTA15', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(4, 'Ilene Lubowitz MD', 'vita.jerde@example.net', 'user', 37, '138 Waelchi Garden Suite 635\nGreysonburgh, LA 84617-7969', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'xY4wvVtBlB', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(5, 'Miss Nya Schneider', 'selena61@example.net', 'user', 54, '775 Lulu Gardens Suite 049\nKemmerville, NM 52847-0914', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'bvvXYkCOis', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(6, 'Valentina Ritchie', 'lottie.kub@example.org', 'user', 30, '32808 Bechtelar Cove Apt. 755\nSwaniawskibury, NM 27425-0076', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'WyUliKhaVi', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(7, 'Ulises Stroman', 'fay.guido@example.net', 'user', 52, '2922 Swift Mountain\nNew Vickie, VT 93113', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '4KVM7DXV0b', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(8, 'Filiberto Legros', 'wolf.eudora@example.net', 'user', 50, '5580 Jamie Loaf\nLake Xavier, MI 47150', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'GtEG8QVd3C', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(9, 'Reilly Jones Sr.', 'zboncak.cole@example.net', 'user', 42, '7388 Kertzmann Course\nCecilmouth, MA 46816', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'zyGXuMGD8k', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(10, 'Mr. Randall Steuber', 'mgibson@example.net', 'user', 19, '5506 Julio Wall Apt. 413\nNorth Rhiannatown, MS 08959', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '25IgUIKvc1', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(11, 'Moshe Hintz', 'lauretta82@example.com', 'user', 40, '7307 Camille Gateway Suite 100\nSpencerton, RI 01786', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Cc034W4CVJ', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(12, 'Ayana Lesch', 'curt90@example.com', 'user', 50, '73135 Araceli Skyway\nEast Russell, OK 04031', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '0IwQmmimMF', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(13, 'Lula Wilderman', 'ortiz.maddison@example.org', 'user', 39, '660 Waters Lock\nNew Verdaview, MA 53730', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'HXw4g6IH2X', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(14, 'Della Mante DDS', 'williamson.precious@example.org', 'user', 30, '2882 Stamm Union Suite 433\nPort Justus, SD 91789-1717', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'liK2m3cMhp', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(15, 'Ms. Vivian Wisoky', 'kellie.witting@example.com', 'user', 24, '64462 Crawford Lodge\nEulahland, WA 15063', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'MKknFUHVda', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(16, 'Prof. Jordi Kemmer PhD', 'clarissa.carter@example.com', 'user', 24, '3869 Marty Union Apt. 727\nJadynland, GA 80651', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'FHRPnhoReM', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(17, 'Blair O\'Kon DVM', 'walsh.aron@example.com', 'user', 19, '9036 Cydney Mills\nStromanview, TX 27168', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'stvxRjSs37', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(18, 'Prof. Troy Ebert', 'kuphal.flavie@example.org', 'user', 41, '876 Virginie Junctions Suite 815\nWardville, NH 99739', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 's4He8ISRcg', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(19, 'Luis Fisher', 'ugrady@example.net', 'user', 32, '8007 Kertzmann Brook Apt. 036\nAlisonhaven, WY 26343', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'eoy7vCXz78', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(20, 'Shyann Klocko', 'mcdermott.mazie@example.net', 'user', 42, '89560 Kay Isle Suite 685\nSouth Armaniland, VA 96380-5677', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'cQUoZeeKJa', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(21, 'Ocie Bednar', 'edison.ryan@example.com', 'user', 19, '7016 Torphy Spring\nEllieside, IL 12476-4460', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'q0xBf77EKD', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(22, 'Mrs. Bernice Ratke', 'rhahn@example.com', 'user', 42, '329 Shanna Throughway\nBergnaumhaven, MD 62907-2676', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '5z2CUFieqI', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(23, 'Prof. Annalise Davis', 'dferry@example.com', 'user', 54, '15467 Schulist Curve Suite 994\nEast Adolfoville, IN 46258-6134', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '1GRTshWz9q', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(24, 'Dr. Maryam Parker', 'elaina.raynor@example.org', 'user', 42, '4666 Willms Light Suite 834\nSouth Dejahburgh, MD 97815-2368', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'O227k8Qv5N', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(25, 'Sadie O\'Kon', 'jacobi.ivah@example.org', 'user', 34, '827 Windler Fords Apt. 328\nSmithammouth, ME 47680', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'XaRA8MRzGB', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(26, 'Dr. Morgan Gutmann', 'schulist.greta@example.org', 'user', 59, '286 Letha Mountain Suite 602\nSouth Flavietown, DE 95793-1373', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'L9lBB5Vnpq', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(27, 'Prof. Natalie Smitham IV', 'dheathcote@example.net', 'user', 37, '56454 Gerlach Track Suite 742\nEast Stephanymouth, OH 43432-4376', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'JDz69AVTMT', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(28, 'Wilfrid Witting', 'jayme.kautzer@example.com', 'user', 59, '171 Adella Court Apt. 769\nPort Albinaborough, NH 12204', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'fgKF6RujJR', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(29, 'Mr. Berta Boehm', 'carlos14@example.net', 'user', 37, '5318 Lynn Circles Apt. 907\nWest Nyahview, MA 20962', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'kIlDLN5KsQ', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(30, 'Ally Cummerata', 'ptorp@example.com', 'user', 33, '54257 Ashley Cape\nNorth Giovannymouth, ID 99776', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'UI48S0mWSc', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(31, 'Dr. Deonte Goyette III', 'holly.nienow@example.org', 'user', 24, '376 Eliza Lock\nArchhaven, ME 86729-9360', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'BjCF8lGg5z', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(32, 'Nola Ullrich', 'brennan16@example.com', 'user', 32, '30200 Annetta Forges\nEast Kurt, AK 52986-6738', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'zX96Du2wNJ', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(33, 'Devante Kuphal', 'monty.dickinson@example.org', 'user', 53, '3381 Pagac Keys\nNorth Marge, AL 83965-4513', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '0Cdk6TZKGM', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(34, 'Dr. Darwin Harber IV', 'jheidenreich@example.net', 'user', 43, '94073 Walter Hill\nJanaeview, DC 65115', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '9OKSPIigFQ', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(35, 'Ms. Bessie Keebler IV', 'trever.schamberger@example.org', 'user', 52, '36402 Marianne Manor Suite 527\nEast Sierra, CA 24920', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'ubOfaEAeYT', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(36, 'Prof. Annie Jones III', 'rmann@example.net', 'user', 36, '9714 Amos Squares\nEast Toy, TX 90348', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '86BHs3t7Ij', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(37, 'Miss Mireya Hoppe', 'smitham.london@example.org', 'user', 39, '107 Effertz Village Apt. 533\nTianashire, WA 24389-3553', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'sgEVlYKhPX', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(38, 'Mr. Griffin Powlowski V', 'gilberto.zieme@example.net', 'user', 21, '9111 Koss Bypass Apt. 165\nMurazikchester, AK 57532', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'wS801aLhE2', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(39, 'Joelle Bradtke I', 'zakary00@example.com', 'user', 55, '758 Laron Tunnel Suite 289\nPort Earlenefurt, TX 18629', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'WdI38DLbp1', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(40, 'Dr. Devan Skiles II', 'petra74@example.com', 'user', 39, '649 Aubree Neck Apt. 237\nWest Sister, CO 80956', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'OtSbAd6UEV', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(41, 'Mateo Zieme', 'mariam.blick@example.com', 'user', 35, '68928 Hettinger Cape\nGleichnerberg, IL 98681', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'flVy3XZM5U', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(42, 'Kelvin Parker', 'jewell02@example.org', 'user', 52, '535 Jeromy Forest Suite 427\nBorermouth, MN 14600', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'J7YdvDnYxa', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(43, 'Augustine Reichel DVM', 'beier.lawrence@example.org', 'user', 52, '115 Antwan Burg Suite 196\nSouth Glennieville, WI 05464', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'hhAiJ2bUpK', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(44, 'Christopher Cartwright', 'isadore.steuber@example.org', 'user', 20, '11146 Ebert Lake\nAmaliaview, OR 11503', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'hrguWZdRvY', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(45, 'Rose Bechtelar', 'bruen.edwina@example.org', 'user', 51, '7866 Morar Turnpike\nNew Robertamouth, WI 50439-4085', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '479ADFszyU', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(46, 'Russel Wolf', 'maybell47@example.com', 'user', 54, '43227 Gerlach Point Suite 719\nAnamouth, AR 21001', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'D2rqAZyCkt', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(47, 'Miss Era Fahey', 'zieme.easton@example.com', 'user', 40, '350 Freida Ramp\nArelyshire, WY 32898', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '9r1sCptXDS', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(48, 'Eleonore Weissnat', 'corrine.hackett@example.net', 'user', 44, '4916 Dangelo Alley Suite 377\nLake Jordon, AZ 54204', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'CNHCt5wgDf', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(49, 'Valentina Goldner', 'leatha43@example.com', 'user', 34, '70163 Auer Pass Suite 165\nNadermouth, GA 56478-7366', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'yYYaRlcRIi', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(50, 'Clement Wolff', 'keara66@example.com', 'user', 45, '58786 Ed Canyon\nHansentown, IL 39046', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'WqeS0gKw4l', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(51, 'Ahmad Daugherty', 'humberto.sipes@example.com', 'user', 56, '11635 Buddy Drive Suite 849\nBayermouth, VA 20764', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'tKUxxYrZf5', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(52, 'Dr. Abraham Veum V', 'larson.lue@example.com', 'user', 34, '110 Koelpin Drive Apt. 279\nRauborough, AL 29547-8227', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'xK72NZgaag', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(53, 'Ms. Ayana Cummerata I', 'schultz.marques@example.com', 'user', 42, '68699 Witting Lodge\nNew Breanahaven, FL 77191-1658', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'BgY8eri5IG', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(54, 'Marianna Sauer', 'elmore61@example.net', 'user', 21, '10118 Alfredo Ridges Apt. 867\nRosenbaumshire, WI 21552-6790', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '7fKOb4cLwa', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(55, 'Ed Rath DDS', 'katherine15@example.org', 'user', 49, '475 Emmerich Village Apt. 940\nEast Olaf, PA 70276-1371', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'U8DYi68f7h', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(56, 'Dr. Cole Little', 'lesley.thiel@example.com', 'user', 37, '34193 Frederique Mews Apt. 052\nClarkburgh, OH 82720', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'iTOqYjltnt', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(57, 'Karlie Tromp Sr.', 'alessandro.lowe@example.org', 'user', 18, '88633 Swift Common\nJodyberg, MN 27780', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'VzCkSnH8Vh', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(58, 'Mr. Aiden Brekke V', 'kkihn@example.net', 'user', 35, '2353 Ryan Roads\nLake Jeanne, NJ 41418-1782', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'WHrBsdFMve', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(59, 'Kari Farrell', 'bahringer.maybelle@example.net', 'user', 42, '807 Keshaun Shoals Apt. 620\nAudreychester, NM 51453-7616', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'K5Cphuuhim', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(60, 'Elinor O\'Keefe', 'kamryn90@example.org', 'user', 54, '6809 Purdy Corner\nEast Kaylahville, NC 56903-6662', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'U2f490DnBM', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(61, 'Brown Robel', 'rjacobs@example.net', 'user', 53, '600 Borer Pike Suite 047\nHodkiewiczchester, SC 08837-5820', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'nu6B5BJqUk', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(62, 'Cory Hackett', 'larkin.sid@example.org', 'user', 38, '596 Harvey Burgs\nCummingsfurt, MI 81123', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '4LJz4vtNuO', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(63, 'Adalberto Bogisich', 'wendell85@example.net', 'user', 55, '95456 Schimmel Canyon Apt. 183\nPort Kirstinview, PA 21262-6642', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'bw0oyN04Ik', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(64, 'Mr. Timmothy Wunsch', 'russel57@example.com', 'user', 43, '7399 Veum Rapid\nKlingbury, ND 54460-2311', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'uAxQwP5g1L', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(65, 'Alex Stark', 'lesch.kenyatta@example.com', 'user', 60, '280 Mabelle Fords\nWehnershire, NM 29052-6535', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'mGFM682HAj', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(66, 'Kayla Kshlerin', 'wisoky.raoul@example.org', 'user', 50, '2700 Consuelo Forks\nLake Wilsonhaven, NY 38167', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'OxCOYBXB3P', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(67, 'Dr. Triston Senger I', 'vhoppe@example.org', 'user', 50, '9130 Roberts Lodge\nEast Ruby, DC 43246-1530', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '6ieazq1Cxs', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(68, 'Kennedi Zboncak', 'medhurst.anibal@example.org', 'user', 28, '43788 Borer Plains Apt. 355\nJeraldmouth, TX 64209-3380', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'o9GLyWEltm', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(69, 'Prof. Kellen Daniel', 'candido.hand@example.org', 'user', 48, '8504 Collier Mills Suite 740\nMarquardtmouth, NJ 80576', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '0BG5m0pUBF', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(70, 'Elouise Trantow', 'drussel@example.org', 'user', 19, '1101 Winston Walk\nLake Ethaborough, MD 03153', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'TWXfkPWByq', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(71, 'Rebekah Douglas IV', 'deckow.molly@example.com', 'user', 54, '544 Austyn Streets\nNew Brandochester, KY 71187-4587', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'ClNbxI5bsk', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(72, 'Garland Satterfield', 'johnson.lillie@example.org', 'user', 60, '186 Grady Hill\nLuettgenfort, KY 93447-1888', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'RRiDNnRN5T', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(73, 'Graham Heidenreich', 'jarrell.abbott@example.org', 'user', 60, '55747 Kristina Meadow\nNorth Samanta, PA 80495', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'pXNVf6WoDA', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(74, 'Jerald Lehner', 'micheal53@example.com', 'user', 49, '9847 Brown Spring\nNorth Alta, LA 90286', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'h8xtX64DTO', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(75, 'Joanny Ritchie', 'dreynolds@example.net', 'user', 45, '553 Luz Alley\nGaylordchester, IL 80564', '2022-07-18 04:22:40', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'DELGY7cveb', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(76, 'Zakary Gerlach IV', 'murray.oconnell@example.com', 'user', 42, '57328 Fredrick Pike Apt. 995\nLehnerfort, VA 54974', '2022-07-18 04:22:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'VGLT0stDmx', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(77, 'Prof. Vito Jenkins', 'groob@example.org', 'user', 60, '478 Kilback Spur\nRunolfssonville, MT 06249-6283', '2022-07-18 04:22:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'FJzsw60x2f', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(78, 'Mr. Garry Dickinson Jr.', 'kitty.kozey@example.net', 'user', 31, '82227 Ryan Lights\nNorth Eveborough, SC 10062-9299', '2022-07-18 04:22:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'CWN7sxc770', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(79, 'Margarete Labadie', 'felton62@example.org', 'user', 51, '44820 Concepcion Canyon Suite 646\nEast Moses, PA 91884-8226', '2022-07-18 04:22:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'mYfpuci8RM', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(80, 'Maegan Gibson', 'gdibbert@example.org', 'user', 52, '5883 Beulah Vista Suite 288\nWestborough, NY 28861', '2022-07-18 04:22:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'w1wwl17jG5', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(81, 'Miss Shanna Lubowitz V', 'thurman.eichmann@example.net', 'user', 25, '3663 Zulauf Rapid\nOthoview, MO 64631', '2022-07-18 04:22:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'OnooFx4jl3', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(82, 'Frieda Kassulke', 'pschneider@example.com', 'user', 37, '15849 Ariane Coves Suite 917\nNorth Sterling, NC 09707', '2022-07-18 04:22:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '8gkUoUtxME', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(83, 'Dayna Barrows', 'rharber@example.com', 'user', 33, '228 Stroman Bypass Apt. 353\nLillyborough, IL 55211-2486', '2022-07-18 04:22:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'FODqzvXJNy', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(84, 'Dr. Willa Spencer MD', 'mcclure.nathan@example.org', 'user', 18, '339 Hyatt Club Suite 458\nAmeliashire, DE 27149', '2022-07-18 04:22:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'kgEYliUqln', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(85, 'Daphne Kub', 'layla.block@example.com', 'user', 38, '725 Nienow Manor Suite 240\nLake Zander, RI 57843', '2022-07-18 04:22:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'wwazWEvj0o', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(86, 'Janiya Goldner Jr.', 'qsmith@example.com', 'user', 48, '4083 Grant Rue\nErdmanborough, NY 51336', '2022-07-18 04:22:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'vGtMwtYWAi', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(87, 'Audie Labadie Sr.', 'ortiz.onie@example.org', 'user', 22, '2488 Brendan Cliffs Apt. 607\nDarianashire, OR 26488', '2022-07-18 04:22:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'fbnmCl5BBZ', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(88, 'Karl Hamill', 'cprohaska@example.net', 'user', 20, '9253 Eloise Parkways\nWest Miloburgh, HI 09791', '2022-07-18 04:22:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '4sAu3LYfGo', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(89, 'Mr. Kelvin Goldner', 'ernser.lauretta@example.org', 'user', 35, '33329 Ryann Squares\nDurganview, AK 08451', '2022-07-18 04:22:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'xpzYcSGq49', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(90, 'Elvie Emmerich', 'ogrant@example.com', 'user', 60, '51739 Alayna Village\nMcCulloughborough, ME 55499-1156', '2022-07-18 04:22:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'qcUGrfqmkK', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(91, 'Dr. Diana Schroeder', 'mazie.russel@example.org', 'user', 49, '8145 Blanda Creek Suite 850\nDachburgh, AZ 77116-5673', '2022-07-18 04:22:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'qg9VVM7Ubj', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(92, 'Shea Legros Sr.', 'hirthe.fidel@example.net', 'user', 34, '847 Block Dale\nSouth Federicochester, NC 96573-6582', '2022-07-18 04:22:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'jljeQCKTNB', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(93, 'Branson Streich', 'abagail64@example.com', 'user', 41, '6506 Murphy Roads\nNew Helmerside, MD 09533', '2022-07-18 04:22:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'aof6CJTqmg', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(94, 'Waldo Corkery', 'rickey.wyman@example.com', 'user', 19, '37556 Brenden Valleys Suite 920\nPhoebeburgh, NY 53557-1132', '2022-07-18 04:22:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'IgsWSQiPF3', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(95, 'Ms. Katrine Thompson Sr.', 'lynch.roberto@example.com', 'user', 20, '468 Natasha Mission Apt. 933\nLarkinshire, MO 49202', '2022-07-18 04:22:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'W6OTeTyOtK', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(96, 'Eileen Marvin III', 'legros.michael@example.org', 'user', 46, '7848 Deon Square Suite 489\nNew Nova, MN 46855', '2022-07-18 04:22:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'JUB8EEd3jO', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(97, 'Miss Esmeralda Heidenreich PhD', 'elise.olson@example.net', 'user', 57, '5117 Lehner Union Apt. 177\nFritschbury, SD 93076-9926', '2022-07-18 04:22:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'E0t3MfxG2x', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(98, 'Quincy Hauck', 'mullrich@example.com', 'user', 24, '888 Anahi Plaza Suite 399\nWymanville, NY 99265', '2022-07-18 04:22:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'TWjpwlVNxQ', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(99, 'Darion Sporer', 'bradford13@example.net', 'user', 52, '655 Spencer Crossing Apt. 627\nPort Sallie, CO 00908', '2022-07-18 04:22:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '5v88e9lSh9', '2022-07-18 04:22:42', '2022-07-18 04:22:42'),
(100, 'Miss Tomasa Hintz II', 'karianne17@example.com', 'user', 25, '77928 Macey Lodge\nAdamsmouth, VT 87431-8834', '2022-07-18 04:22:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'VkLVU3acLJ', '2022-07-18 04:22:42', '2022-07-18 04:22:42');
--
-- Base de données : `image`
--
CREATE DATABASE IF NOT EXISTS `image` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `image`;

-- --------------------------------------------------------

--
-- Structure de la table `documents`
--

DROP TABLE IF EXISTS `documents`;
CREATE TABLE IF NOT EXISTS `documents` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2022_07_16_143910_create_documents_table', 1);

-- --------------------------------------------------------

--
-- Structure de la table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
--
-- Base de données : `j_sendmail`
--
CREATE DATABASE IF NOT EXISTS `j_sendmail` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `j_sendmail`;

-- --------------------------------------------------------

--
-- Structure de la table `courriers`
--

DROP TABLE IF EXISTS `courriers`;
CREATE TABLE IF NOT EXISTS `courriers` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `courrier_libele` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `courrier_date_arrive` date NOT NULL,
  `courrier_status` enum('enStok','enCours','destoke') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `emeteur_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `emplacement_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `receptioniste` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `courriers_emeteur_id_foreign` (`emeteur_id`),
  KEY `courriers_user_id_foreign` (`user_id`),
  KEY `courriers_emplacement_id_foreign` (`emplacement_id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `courriers`
--

INSERT INTO `courriers` (`id`, `courrier_libele`, `courrier_date_arrive`, `courrier_status`, `emeteur_id`, `user_id`, `emplacement_id`, `created_at`, `updated_at`, `receptioniste`) VALUES
(14, 'sac', '2022-09-26', 'enStok', 2, 13, 2, '2022-09-26 15:00:11', '2022-09-26 15:00:11', 'dubelnguemle@gmail.com'),
(15, 'abdou', '2022-10-13', 'destoke', 2, 14, 2, '2022-10-12 08:24:49', '2022-10-12 08:26:16', 'njutapmvouiabdouchirac@gmail.com');

-- --------------------------------------------------------

--
-- Structure de la table `destinataires`
--

DROP TABLE IF EXISTS `destinataires`;
CREATE TABLE IF NOT EXISTS `destinataires` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `destinataire_noms` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `destinataire_prenoms` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `destinataire_email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `destinataire_telephone` int NOT NULL,
  `destinataire_pasword` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `emeteurs`
--

DROP TABLE IF EXISTS `emeteurs`;
CREATE TABLE IF NOT EXISTS `emeteurs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `emeteur_noms` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `emeteurs`
--

INSERT INTO `emeteurs` (`id`, `emeteur_noms`, `created_at`, `updated_at`) VALUES
(1, 'dubel', '2022-09-13 13:02:54', '2022-09-13 13:02:54'),
(2, 'solange', '2022-09-13 13:05:04', '2022-09-14 08:22:33'),
(3, 'abdel', '2022-09-20 10:14:44', '2022-09-20 10:14:44');

-- --------------------------------------------------------

--
-- Structure de la table `emplacements`
--

DROP TABLE IF EXISTS `emplacements`;
CREATE TABLE IF NOT EXISTS `emplacements` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `emplacement_noms` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `emplacement_detail` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `emplacements`
--

INSERT INTO `emplacements` (`id`, `emplacement_noms`, `emplacement_detail`, `created_at`, `updated_at`) VALUES
(1, 'la  presse', 'solantinessa', '2022-09-13 13:05:41', '2022-09-13 13:05:41'),
(2, 'salle de reunion', 'situe face a la direction', '2022-09-20 10:16:14', '2022-09-20 10:16:14');

-- --------------------------------------------------------

--
-- Structure de la table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `historiques`
--

DROP TABLE IF EXISTS `historiques`;
CREATE TABLE IF NOT EXISTS `historiques` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `poste_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `historiques_poste_id_foreign` (`poste_id`),
  KEY `historiques_user_id_foreign` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `images`
--

DROP TABLE IF EXISTS `images`;
CREATE TABLE IF NOT EXISTS `images` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `images` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `images`
--

INSERT INTO `images` (`id`, `images`, `created_at`, `updated_at`) VALUES
(13, 'posts/LTG5XRWWJ72nwytAZji7L7O2bGWOBSmx14FrcRfH.png', '2022-09-20 13:45:39', '2022-09-20 13:45:39'),
(14, 'posts/RYXMB2LXvYYVCmNNxBUfCNB5u0TxJQbELHkAnv48.jpg', '2022-09-20 13:46:21', '2022-09-20 13:46:21'),
(15, 'posts/KyoYRuhrZqcZj7fq6iDeUVDU8B9Ik569HJMB9BmU.jpg', '2022-09-20 13:47:16', '2022-09-20 13:47:16'),
(16, 'posts/CwYeHBmsEKZf6L93Br12i9oGCpLAe4Ie7DBPoKX9.jpg', '2022-09-21 07:22:57', '2022-09-21 07:22:57'),
(17, 'posts/zrovacK8Bx5YBTQqCtK15IDyvMThzBVU1VSizH40.png', '2022-09-23 09:24:28', '2022-09-23 09:24:28'),
(18, 'posts/0nXwpFilaPa4rxw32Q78hgWKPZi6lXznz8YrPWkB.jpg', '2022-10-12 08:15:21', '2022-10-12 08:15:21'),
(19, 'posts/IbP6HyfOHWBDfya8MbuzqAUKApqgqrYUlogDwZxZ.jpg', '2022-10-12 08:22:47', '2022-10-12 08:22:47'),
(20, 'posts/tsh9wbh2wg5ZwuoTAsApvWIwCIbedC3OgIwqECh4.jpg', '2022-10-12 13:43:28', '2022-10-12 13:43:28'),
(21, 'posts/83j1ig5GaZhsek84N1ijjF7RZ1P9pheYHXB4xtzL.jpg', '2022-10-15 14:20:28', '2022-10-15 14:20:28');

-- --------------------------------------------------------

--
-- Structure de la table `message`
--

DROP TABLE IF EXISTS `message`;
CREATE TABLE IF NOT EXISTS `message` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2022_06_16_114634_create_emplacements_table', 1),
(5, '2022_06_16_115737_create_destinataires_table', 1),
(6, '2022_06_16_121946_create_postes_table', 1),
(7, '2022_06_16_130707_create_historiques_table', 1),
(8, '2022_06_16_132853_create_emeteurs_table', 1),
(9, '2022_06_16_133129_create_courriers_table', 1),
(10, '2022_06_20_105740_create_roles_table', 1),
(11, '2022_06_24_082540_create_messages_table', 1),
(12, '2022_07_05_133006_create_notifications_table', 1),
(13, '2022_07_17_153444_create_images_table', 1),
(14, '2022_08_12_120856_userrole_table', 1),
(15, '2022_08_16_102418_permission_table', 1),
(16, '2022_08_16_102503_userpermission_table', 1),
(17, '2022_08_16_103713_user_permissions_table', 1),
(18, '2022_08_16_103910_permissions_table', 1);

-- --------------------------------------------------------

--
-- Structure de la table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint UNSIGNED NOT NULL,
  `data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `notifications`
--

INSERT INTO `notifications` (`id`, `type`, `notifiable_type`, `notifiable_id`, `data`, `read_at`, `created_at`, `updated_at`) VALUES
('1576da76-add0-4fc6-a448-8c5418d96927', 'App\\Notifications\\courriernotification', 'App\\Models\\User', 1, '{\"state\":{\"courrier_libele\":\"telephone\",\"courrier_date_arrive\":\"2022-09-12\",\"emeteur_id\":\"2\",\"user_id\":\"1\",\"emplacement_id\":\"1\"}}', NULL, '2022-09-13 13:06:22', '2022-09-13 13:06:22'),
('a93ff9eb-1fde-469a-addb-97da9e158e13', 'App\\Notifications\\courriernotification', 'App\\Models\\User', 5, '{\"state\":{\"courrier_libele\":\"telephone\",\"courrier_date_arrive\":\"2022-09-12\",\"emeteur_id\":\"2\",\"user_id\":\"1\",\"emplacement_id\":\"1\"}}', NULL, '2022-09-13 13:06:22', '2022-09-13 13:06:22'),
('af242ab5-8717-496b-9a1a-8598ce09e23c', 'App\\Notifications\\courriernotification', 'App\\Models\\User', 1, '{\"state\":{\"courrier_libele\":\"djdjddkj\",\"courrier_date_arrive\":\"2022-09-09\",\"emeteur_id\":\"2\",\"user_id\":\"5\",\"emplacement_id\":\"1\"}}', NULL, '2022-09-15 06:37:27', '2022-09-15 06:37:27'),
('53a59a7d-6792-4b2e-a3fb-945dcf8fb50b', 'App\\Notifications\\courriernotification', 'App\\Models\\User', 5, '{\"state\":{\"courrier_libele\":\"djdjddkj\",\"courrier_date_arrive\":\"2022-09-09\",\"emeteur_id\":\"2\",\"user_id\":\"5\",\"emplacement_id\":\"1\"}}', NULL, '2022-09-15 06:37:27', '2022-09-15 06:37:27'),
('3d7bb15d-a744-4773-998b-80d590e61bd7', 'App\\Notifications\\courriernotification', 'App\\Models\\User', 6, '{\"state\":{\"courrier_libele\":\"djdjddkj\",\"courrier_date_arrive\":\"2022-09-09\",\"emeteur_id\":\"2\",\"user_id\":\"5\",\"emplacement_id\":\"1\"}}', NULL, '2022-09-15 06:37:27', '2022-09-15 06:37:27'),
('15dd23f7-54d0-432f-949f-f4d681df574c', 'App\\Notifications\\courriernotification', 'App\\Models\\User', 1, '{\"state\":{\"courrier_libele\":\"sacs\",\"courrier_date_arrive\":\"2022-09-20\",\"emeteur_id\":\"2\",\"user_id\":\"1\",\"emplacement_id\":\"1\"}}', NULL, '2022-09-19 15:19:16', '2022-09-19 15:19:16'),
('5269aff9-4de2-444a-adb5-197ed614ee53', 'App\\Notifications\\courriernotification', 'App\\Models\\User', 8, '{\"state\":{\"courrier_libele\":\"sacs\",\"courrier_date_arrive\":\"2022-09-20\",\"emeteur_id\":\"2\",\"user_id\":\"1\",\"emplacement_id\":\"1\"}}', NULL, '2022-09-19 15:19:17', '2022-09-19 15:19:17'),
('b2ac49bc-205f-4430-8d6d-56d51b215315', 'App\\Notifications\\courriernotification', 'App\\Models\\User', 1, '{\"state\":{\"courrier_libele\":\"tanqi\",\"courrier_date_arrive\":\"2022-09-21\",\"emeteur_id\":\"2\",\"user_id\":\"1\",\"emplacement_id\":\"1\"}}', NULL, '2022-09-20 09:03:32', '2022-09-20 09:03:32'),
('d5b81210-59df-4611-8cbe-943d0cccbda3', 'App\\Notifications\\courriernotification', 'App\\Models\\User', 8, '{\"state\":{\"courrier_libele\":\"tanqi\",\"courrier_date_arrive\":\"2022-09-21\",\"emeteur_id\":\"2\",\"user_id\":\"1\",\"emplacement_id\":\"1\"}}', NULL, '2022-09-20 09:03:32', '2022-09-20 09:03:32'),
('63dd9c16-5ca2-4efc-9a62-86dd506250e9', 'App\\Notifications\\courriernotification', 'App\\Models\\User', 1, '{\"state\":{\"courrier_libele\":\"mhfdssdc\",\"courrier_date_arrive\":\"2022-09-20\",\"emeteur_id\":\"2\",\"user_id\":\"1\",\"emplacement_id\":\"1\"}}', NULL, '2022-09-20 09:05:24', '2022-09-20 09:05:24'),
('2a9b5956-50cd-4f03-a1b0-af6e91e40d02', 'App\\Notifications\\courriernotification', 'App\\Models\\User', 8, '{\"state\":{\"courrier_libele\":\"mhfdssdc\",\"courrier_date_arrive\":\"2022-09-20\",\"emeteur_id\":\"2\",\"user_id\":\"1\",\"emplacement_id\":\"1\"}}', NULL, '2022-09-20 09:05:24', '2022-09-20 09:05:24'),
('e5ca28ef-ac14-41ea-a90e-ef9a8ff21d72', 'App\\Notifications\\courriernotification', 'App\\Models\\User', 1, '{\"state\":{\"courrier_libele\":\"chaussure\",\"courrier_date_arrive\":\"2022-09-22\",\"receptioniste\":\"dubelnguemle@gmail.com\",\"emeteur_id\":\"2\",\"user_id\":\"8\",\"emplacement_id\":\"1\"}}', NULL, '2022-09-22 15:16:47', '2022-09-22 15:16:47'),
('ec9c43a8-596c-4e59-8da8-5a50ce5f107d', 'App\\Notifications\\courriernotification', 'App\\Models\\User', 8, '{\"state\":{\"courrier_libele\":\"chaussure\",\"courrier_date_arrive\":\"2022-09-22\",\"receptioniste\":\"dubelnguemle@gmail.com\",\"emeteur_id\":\"2\",\"user_id\":\"8\",\"emplacement_id\":\"1\"}}', NULL, '2022-09-22 15:16:47', '2022-09-22 15:16:47'),
('448ea342-6307-44f6-bde5-b880d433473e', 'App\\Notifications\\courriernotification', 'App\\Models\\User', 9, '{\"state\":{\"courrier_libele\":\"chaussure\",\"courrier_date_arrive\":\"2022-09-22\",\"receptioniste\":\"dubelnguemle@gmail.com\",\"emeteur_id\":\"2\",\"user_id\":\"8\",\"emplacement_id\":\"1\"}}', NULL, '2022-09-22 15:16:47', '2022-09-22 15:16:47'),
('286ecbd6-f37b-4a04-a1e6-2acd503eb0fc', 'App\\Notifications\\courriernotification', 'App\\Models\\User', 10, '{\"state\":{\"courrier_libele\":\"chaussure\",\"courrier_date_arrive\":\"2022-09-22\",\"receptioniste\":\"dubelnguemle@gmail.com\",\"emeteur_id\":\"2\",\"user_id\":\"8\",\"emplacement_id\":\"1\"}}', NULL, '2022-09-22 15:16:47', '2022-09-22 15:16:47'),
('53c214b5-7303-4391-a402-01cf42f8be1a', 'App\\Notifications\\courriernotification', 'App\\Models\\User', 11, '{\"state\":{\"courrier_libele\":\"chaussure\",\"courrier_date_arrive\":\"2022-09-22\",\"receptioniste\":\"dubelnguemle@gmail.com\",\"emeteur_id\":\"2\",\"user_id\":\"8\",\"emplacement_id\":\"1\"}}', NULL, '2022-09-22 15:16:47', '2022-09-22 15:16:47'),
('b4016ba7-c47f-427c-90c9-4516598f8777', 'App\\Notifications\\courriernotification', 'App\\Models\\User', 12, '{\"state\":{\"courrier_libele\":\"chaussure\",\"courrier_date_arrive\":\"2022-09-22\",\"receptioniste\":\"dubelnguemle@gmail.com\",\"emeteur_id\":\"2\",\"user_id\":\"8\",\"emplacement_id\":\"1\"}}', NULL, '2022-09-22 15:16:47', '2022-09-22 15:16:47'),
('1187f59c-6042-4d29-831c-4864c945c07a', 'App\\Notifications\\courriernotification', 'App\\Models\\User', 1, '{\"state\":{\"courrier_libele\":\"chaussure\",\"courrier_date_arrive\":\"2022-09-22\",\"receptioniste\":\"dubelnguemle@gmail.com\",\"emeteur_id\":\"2\",\"user_id\":\"10\",\"emplacement_id\":\"2\"}}', NULL, '2022-09-22 15:24:28', '2022-09-22 15:24:28'),
('495ffcfd-ac0f-4915-a13e-0a257bafa0b3', 'App\\Notifications\\courriernotification', 'App\\Models\\User', 8, '{\"state\":{\"courrier_libele\":\"chaussure\",\"courrier_date_arrive\":\"2022-09-22\",\"receptioniste\":\"dubelnguemle@gmail.com\",\"emeteur_id\":\"2\",\"user_id\":\"10\",\"emplacement_id\":\"2\"}}', NULL, '2022-09-22 15:24:28', '2022-09-22 15:24:28'),
('250408f2-0b08-42bb-a6c3-0e1c4000fa50', 'App\\Notifications\\courriernotification', 'App\\Models\\User', 9, '{\"state\":{\"courrier_libele\":\"chaussure\",\"courrier_date_arrive\":\"2022-09-22\",\"receptioniste\":\"dubelnguemle@gmail.com\",\"emeteur_id\":\"2\",\"user_id\":\"10\",\"emplacement_id\":\"2\"}}', NULL, '2022-09-22 15:24:28', '2022-09-22 15:24:28'),
('d4a8b111-89bc-4a25-b9b0-699142c64bcb', 'App\\Notifications\\courriernotification', 'App\\Models\\User', 10, '{\"state\":{\"courrier_libele\":\"chaussure\",\"courrier_date_arrive\":\"2022-09-22\",\"receptioniste\":\"dubelnguemle@gmail.com\",\"emeteur_id\":\"2\",\"user_id\":\"10\",\"emplacement_id\":\"2\"}}', NULL, '2022-09-22 15:24:28', '2022-09-22 15:24:28'),
('b9dc60ee-3ea8-4c4e-9f0d-ee840bd1c865', 'App\\Notifications\\courriernotification', 'App\\Models\\User', 11, '{\"state\":{\"courrier_libele\":\"chaussure\",\"courrier_date_arrive\":\"2022-09-22\",\"receptioniste\":\"dubelnguemle@gmail.com\",\"emeteur_id\":\"2\",\"user_id\":\"10\",\"emplacement_id\":\"2\"}}', NULL, '2022-09-22 15:24:28', '2022-09-22 15:24:28'),
('43bbd651-3698-4d40-ab35-4f96f9aab42c', 'App\\Notifications\\courriernotification', 'App\\Models\\User', 12, '{\"state\":{\"courrier_libele\":\"chaussure\",\"courrier_date_arrive\":\"2022-09-22\",\"receptioniste\":\"dubelnguemle@gmail.com\",\"emeteur_id\":\"2\",\"user_id\":\"10\",\"emplacement_id\":\"2\"}}', NULL, '2022-09-22 15:24:28', '2022-09-22 15:24:28'),
('bbea48bc-996a-4aec-b193-c18e7c8d3521', 'App\\Notifications\\courriernotification', 'App\\Models\\User', 1, '{\"state\":{\"courrier_libele\":\"sac\",\"courrier_date_arrive\":\"2022-09-26\",\"receptioniste\":\"dubelnguemle@gmail.com\",\"emeteur_id\":\"2\",\"user_id\":\"13\",\"emplacement_id\":\"2\"}}', NULL, '2022-09-26 15:00:35', '2022-09-26 15:00:35'),
('ff4d2db6-020f-4422-aede-37779991337c', 'App\\Notifications\\courriernotification', 'App\\Models\\User', 13, '{\"state\":{\"courrier_libele\":\"sac\",\"courrier_date_arrive\":\"2022-09-26\",\"receptioniste\":\"dubelnguemle@gmail.com\",\"emeteur_id\":\"2\",\"user_id\":\"13\",\"emplacement_id\":\"2\"}}', NULL, '2022-09-26 15:00:35', '2022-09-26 15:00:35'),
('00de673d-4a39-4336-967f-7ed49cf1fde4', 'App\\Notifications\\courriernotification', 'App\\Models\\User', 1, '{\"state\":{\"courrier_libele\":\"abdou\",\"courrier_date_arrive\":\"2022-10-13\",\"receptioniste\":\"njutapmvouiabdouchirac@gmail.com\",\"emeteur_id\":\"2\",\"user_id\":\"14\",\"emplacement_id\":\"2\"}}', NULL, '2022-10-12 08:24:54', '2022-10-12 08:24:54'),
('47f10c91-bce3-4842-9cbc-2c4fac890faf', 'App\\Notifications\\courriernotification', 'App\\Models\\User', 13, '{\"state\":{\"courrier_libele\":\"abdou\",\"courrier_date_arrive\":\"2022-10-13\",\"receptioniste\":\"njutapmvouiabdouchirac@gmail.com\",\"emeteur_id\":\"2\",\"user_id\":\"14\",\"emplacement_id\":\"2\"}}', NULL, '2022-10-12 08:24:54', '2022-10-12 08:24:54'),
('a13c70a4-10d0-47b3-8b99-f1df4c0932b7', 'App\\Notifications\\courriernotification', 'App\\Models\\User', 14, '{\"state\":{\"courrier_libele\":\"abdou\",\"courrier_date_arrive\":\"2022-10-13\",\"receptioniste\":\"njutapmvouiabdouchirac@gmail.com\",\"emeteur_id\":\"2\",\"user_id\":\"14\",\"emplacement_id\":\"2\"}}', NULL, '2022-10-12 08:24:54', '2022-10-12 08:24:54');

-- --------------------------------------------------------

--
-- Structure de la table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
CREATE TABLE IF NOT EXISTS `permissions` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `permission_libele` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `permissions`
--

INSERT INTO `permissions` (`id`, `permission_libele`) VALUES
(1, 'ajouter les courriers'),
(2, 'modifier les courriers'),
(3, 'supprimer les courriers'),
(4, 'déstocker les courriers'),
(5, 'ajouter les emplacements'),
(6, 'modifier les emplacements'),
(7, 'ajouter les émetteurs'),
(8, 'modifier les émetteurs'),
(9, 'valider la réception des courriers'),
(10, 'voir les courriers'),
(11, 'consulter la liste des courriers'),
(12, 'consulter la liste des emplacements'),
(13, 'consulter la liste des émetteurs'),
(14, 'ajouter les utilisateurs'),
(15, 'afficher les utilisateurs'),
(16, 'consulter la liste des utilisateurs'),
(17, 'modifier le profil des utilisateurs'),
(18, 'voir les emplacements'),
(19, 'consulter la liste des postes'),
(20, 'modifier un poste'),
(21, 'voir son profil'),
(22, 'ajouter les postes'),
(23, 'modifier les paramètres');

-- --------------------------------------------------------

--
-- Structure de la table `postes`
--

DROP TABLE IF EXISTS `postes`;
CREATE TABLE IF NOT EXISTS `postes` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `poste_libele` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `postes_id_unique` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `postes`
--

INSERT INTO `postes` (`id`, `poste_libele`, `created_at`, `updated_at`) VALUES
(1, 'directeur', NULL, NULL),
(2, 'marquetiste', '2022-09-14 07:49:26', '2022-09-16 09:27:24'),
(3, 'developpeur', '2022-09-21 09:25:39', '2022-09-21 09:25:39');

-- --------------------------------------------------------

--
-- Structure de la table `receptionistes`
--

DROP TABLE IF EXISTS `receptionistes`;
CREATE TABLE IF NOT EXISTS `receptionistes` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `receptioniste_noms` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `receptioniste_prenoms` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `receptioniste_email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `receptioniste_password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_libele` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `roles`
--

INSERT INTO `roles` (`id`, `role_libele`) VALUES
(1, 'admin');

-- --------------------------------------------------------

--
-- Structure de la table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(191) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_agent` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `payload` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('ONVNlGOgNNDvlNj32aR9p1rSc0Ig7BbXJcU5n84P', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', 'YTo1OntzOjY6Il90b2tlbiI7czo0MDoiSFFPTUtOd2FRUXh1dFRrbk5ld0pBR3BuQXBwSXhzblBJejh3eXg5WSI7czozOiJ1cmwiO2E6MDp7fXM6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjMyOiJodHRwOi8vMTI3LjAuMC4xOjgwMDAvcGFyYW1ldHRyZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7fQ==', 1664263390),
('DnNqaLeOoP7AyFTSwLbFPaIjqJfJpRT1wtBllRyQ', 13, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edg/105.0.1343.50', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiMVNzMFRodnBmcjR6aVNKaWttMGNYd05nMW8ycnFxSERSRzB5YWZjUCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9kYXNoYm9hcmQiO31zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxMzt9', 1664267723),
('Dslry9fqnTWcgedVElXGRf9nxlcgk91FsGb6MHmR', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiOHdSR056NGFjQUgwUU5zVm8yNllZOEhKQTZGM296Rm0yWlhVeHl5MCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9sb2dpbiI7fX0=', 1664268154);

-- --------------------------------------------------------

--
-- Structure de la table `userrole`
--

DROP TABLE IF EXISTS `userrole`;
CREATE TABLE IF NOT EXISTS `userrole` (
  `user_id` bigint UNSIGNED NOT NULL,
  `role_id` bigint UNSIGNED NOT NULL,
  KEY `userrole_user_id_foreign` (`user_id`),
  KEY `userrole_role_id_foreign` (`role_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `userrole`
--

INSERT INTO `userrole` (`user_id`, `role_id`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `poste_id` bigint UNSIGNED NOT NULL,
  `image_id` bigint UNSIGNED DEFAULT NULL,
  `password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_type` enum('admin','user') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `role_id` bigint UNSIGNED NOT NULL DEFAULT '1',
  `status` enum('actif','inactif') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_remember_token_unique` (`remember_token`),
  KEY `users_poste_id_foreign` (`poste_id`),
  KEY `users_image_id_foreign` (`image_id`),
  KEY `users_role_id_foreign` (`role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `poste_id`, `image_id`, `password`, `user_type`, `email_verified_at`, `role_id`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'dubel', 'nguemle', 'dubelnguemle@gmail.com', 1, 18, '$2y$10$652LVFQNr0rNHYaZhGXIjOMNwUkr//c05Y4R1ciGTxiPizLDgJaSO', 'admin', NULL, 1, 'actif', NULL, NULL, '2022-10-12 08:19:26'),
(13, 'meje', 'upgrade', 'mejeupgrade@gmail.com', 2, NULL, '$2y$10$svZsNRWGJrut.GUnha.h5uAN/M1TC2HSfiUZv.ZhySp/tSjAfp5tS', 'user', NULL, 1, 'inactif', NULL, '2022-09-23 09:27:51', '2022-09-26 09:20:36'),
(18, 'abdou', 'princesse', 'njutapmvouiabdouchirac@gmail.com', 3, NULL, '$2y$10$nr7rLKgsQJw3DjcjhpbRguLT7ZWeDKnHN7kEy6vF8CBZWmYvimbd6', 'user', NULL, 1, 'actif', NULL, '2022-10-15 14:22:04', '2022-10-15 14:22:04'),
(15, 'abdou', 'maeva', 'r@gmail.com', 3, 21, '$2y$10$FVlwGtt9umKLwgHm13U5/uu4utvY..XWryW/ADeeuA43XY6.3IH3i', 'user', NULL, 1, 'actif', NULL, '2022-10-12 13:45:40', '2022-10-15 14:20:28');

-- --------------------------------------------------------

--
-- Structure de la table `user_permissions`
--

DROP TABLE IF EXISTS `user_permissions`;
CREATE TABLE IF NOT EXISTS `user_permissions` (
  `user_id` bigint UNSIGNED NOT NULL,
  `permission_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `user_permissions_user_id_foreign` (`user_id`),
  KEY `user_permissions_permission_id_foreign` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `user_permissions`
--

INSERT INTO `user_permissions` (`user_id`, `permission_id`, `created_at`, `updated_at`) VALUES
(1, 21, '2022-09-08 08:25:00', '2022-09-08 08:25:00'),
(1, 11, '2022-09-08 08:25:00', '2022-09-08 08:25:00'),
(1, 3, '2022-09-08 08:25:00', '2022-09-08 08:25:00'),
(1, 5, '2022-09-08 08:25:00', '2022-09-08 08:25:00'),
(1, 16, '2022-09-08 08:25:00', '2022-09-08 08:25:00'),
(1, 8, '2022-09-08 08:25:00', '2022-09-08 08:25:00'),
(1, 4, '2022-09-08 08:25:00', '2022-09-08 08:25:00'),
(1, 9, '2022-09-08 08:25:00', '2022-09-08 08:25:00'),
(1, 17, '2022-09-08 08:25:00', '2022-09-08 08:25:00'),
(1, 10, '2022-09-08 08:25:00', '2022-09-08 08:25:00'),
(1, 14, '2022-09-08 08:25:00', '2022-09-08 08:25:00'),
(1, 18, '2022-09-08 08:25:00', '2022-09-08 08:25:00'),
(1, 17, '2022-09-08 08:25:00', '2022-09-08 08:25:00'),
(1, 9, '2022-09-08 08:25:00', '2022-09-08 08:25:00'),
(1, 18, '2022-09-08 08:25:00', '2022-09-08 08:25:00'),
(1, 10, '2022-09-08 08:25:00', '2022-09-08 08:25:00'),
(1, 5, '2022-09-08 08:25:00', '2022-09-08 08:25:00'),
(1, 11, '2022-09-08 08:25:00', '2022-09-08 08:25:00'),
(1, 19, '2022-09-08 08:25:00', '2022-09-08 08:25:00'),
(1, 4, '2022-09-08 08:25:00', '2022-09-08 08:25:00'),
(1, 13, '2022-09-08 08:25:00', '2022-09-08 08:25:00'),
(1, 8, '2022-09-08 08:25:00', '2022-09-08 08:25:00'),
(1, 15, '2022-09-08 08:25:00', '2022-09-08 08:25:00'),
(1, 6, '2022-09-08 08:25:00', '2022-09-08 08:25:00'),
(1, 16, '2022-09-08 08:25:00', '2022-09-08 08:25:00'),
(1, 13, '2022-09-08 08:25:00', '2022-09-08 08:25:00'),
(1, 2, '2022-09-08 08:21:59', '2022-09-08 08:21:59'),
(1, 12, '2022-09-08 08:21:59', '2022-09-08 08:21:59'),
(1, 1, '2022-09-08 08:21:59', '2022-09-08 08:21:59'),
(1, 7, '2022-09-08 08:25:00', '2022-09-08 08:25:00'),
(1, 13, '2022-09-08 08:01:25', '2022-09-08 08:01:25'),
(1, 6, '2022-09-08 08:01:25', '2022-09-08 08:01:25'),
(1, 12, '2022-09-08 08:01:25', '2022-09-08 08:01:25'),
(1, 20, '2022-09-08 08:01:25', '2022-09-08 08:01:25'),
(1, 16, '2022-09-08 08:21:59', '2022-09-08 08:21:59'),
(1, 6, '2022-09-08 08:21:59', '2022-09-08 08:21:59'),
(1, 8, '2022-09-08 08:21:59', '2022-09-08 08:21:59'),
(1, 1, '2022-09-08 08:25:00', '2022-09-08 08:25:00'),
(1, 13, '2022-09-08 08:21:59', '2022-09-08 08:21:59'),
(1, 4, '2022-09-08 08:21:59', '2022-09-08 08:21:59'),
(1, 19, '2022-09-08 08:01:25', '2022-09-08 08:01:25'),
(1, 11, '2022-09-08 08:01:25', '2022-09-08 08:01:25'),
(3, 11, '2022-09-08 06:59:21', '2022-09-08 06:59:21'),
(1, 5, '2022-09-08 08:01:25', '2022-09-08 08:01:25'),
(1, 10, '2022-09-08 08:01:25', '2022-09-08 08:01:25'),
(1, 18, '2022-09-08 08:01:25', '2022-09-08 08:01:25'),
(1, 9, '2022-09-08 08:21:59', '2022-09-08 08:21:59'),
(1, 19, '2022-09-08 08:25:00', '2022-09-08 08:25:00'),
(1, 12, '2022-09-08 08:25:00', '2022-09-08 08:25:00'),
(1, 17, '2022-09-08 08:21:59', '2022-09-08 08:21:59'),
(1, 2, '2022-09-08 08:25:00', '2022-09-08 08:25:00'),
(1, 18, '2022-09-08 08:21:59', '2022-09-08 08:21:59'),
(1, 14, '2022-09-08 08:21:59', '2022-09-08 08:21:59'),
(1, 10, '2022-09-08 08:21:59', '2022-09-08 08:21:59'),
(1, 17, '2022-09-08 08:01:25', '2022-09-08 08:01:25'),
(1, 9, '2022-09-08 08:01:25', '2022-09-08 08:01:25'),
(1, 4, '2022-09-08 08:01:25', '2022-09-08 08:01:25'),
(1, 8, '2022-09-08 08:01:25', '2022-09-08 08:01:25'),
(1, 16, '2022-09-08 08:01:25', '2022-09-08 08:01:25'),
(1, 5, '2022-09-08 08:21:59', '2022-09-08 08:21:59'),
(1, 3, '2022-09-08 08:21:59', '2022-09-08 08:21:59'),
(1, 11, '2022-09-08 08:21:59', '2022-09-08 08:21:59'),
(1, 20, '2022-09-08 08:25:00', '2022-09-08 08:25:00'),
(5, 1, '2022-09-14 09:45:13', '2022-09-14 09:45:13'),
(5, 1, '2022-09-14 14:45:06', '2022-09-14 14:45:06'),
(5, 21, '2022-09-14 14:45:06', '2022-09-14 14:45:06'),
(6, 11, '2022-09-15 15:06:01', '2022-09-15 15:06:01'),
(6, 11, '2022-09-16 10:17:40', '2022-09-16 10:17:40'),
(6, 21, '2022-09-16 10:17:40', '2022-09-16 10:17:40'),
(1, 22, NULL, NULL),
(1, 23, NULL, NULL),
(8, 9, '2022-09-22 14:32:07', '2022-09-22 14:32:07'),
(13, 22, '2022-09-23 11:37:22', '2022-09-23 11:37:22'),
(13, 21, '2022-09-23 11:37:22', '2022-09-23 11:37:22'),
(13, 20, '2022-09-23 11:37:22', '2022-09-23 11:37:22'),
(13, 19, '2022-09-23 11:37:22', '2022-09-23 11:37:22'),
(13, 18, '2022-09-23 11:37:22', '2022-09-23 11:37:22'),
(13, 17, '2022-09-23 11:37:22', '2022-09-23 11:37:22'),
(13, 16, '2022-09-23 11:37:22', '2022-09-23 11:37:22'),
(13, 15, '2022-09-23 11:37:22', '2022-09-23 11:37:22'),
(13, 14, '2022-09-23 11:37:22', '2022-09-23 11:37:22'),
(13, 13, '2022-09-23 11:37:22', '2022-09-23 11:37:22'),
(13, 12, '2022-09-23 11:37:22', '2022-09-23 11:37:22'),
(13, 11, '2022-09-23 11:37:22', '2022-09-23 11:37:22'),
(13, 10, '2022-09-23 11:37:22', '2022-09-23 11:37:22'),
(13, 9, '2022-09-23 11:37:22', '2022-09-23 11:37:22'),
(13, 8, '2022-09-23 11:37:22', '2022-09-23 11:37:22'),
(13, 7, '2022-09-23 11:37:22', '2022-09-23 11:37:22'),
(13, 6, '2022-09-23 11:37:22', '2022-09-23 11:37:22'),
(13, 5, '2022-09-23 11:37:22', '2022-09-23 11:37:22'),
(13, 4, '2022-09-23 11:37:22', '2022-09-23 11:37:22'),
(13, 3, '2022-09-23 11:37:22', '2022-09-23 11:37:22'),
(13, 2, '2022-09-23 11:37:22', '2022-09-23 11:37:22'),
(13, 1, '2022-09-23 11:37:22', '2022-09-23 11:37:22'),
(14, 1, '2022-10-12 08:22:15', '2022-10-12 08:22:15'),
(14, 2, '2022-10-12 08:22:15', '2022-10-12 08:22:15'),
(14, 3, '2022-10-12 08:22:15', '2022-10-12 08:22:15'),
(14, 4, '2022-10-12 08:22:15', '2022-10-12 08:22:15'),
(14, 5, '2022-10-12 08:22:15', '2022-10-12 08:22:15'),
(14, 6, '2022-10-12 08:22:15', '2022-10-12 08:22:15'),
(14, 7, '2022-10-12 08:22:15', '2022-10-12 08:22:15'),
(14, 8, '2022-10-12 08:22:15', '2022-10-12 08:22:15'),
(14, 9, '2022-10-12 08:22:15', '2022-10-12 08:22:15'),
(14, 10, '2022-10-12 08:22:15', '2022-10-12 08:22:15'),
(14, 11, '2022-10-12 08:22:15', '2022-10-12 08:22:15'),
(14, 12, '2022-10-12 08:22:15', '2022-10-12 08:22:15'),
(14, 13, '2022-10-12 08:22:15', '2022-10-12 08:22:15'),
(14, 14, '2022-10-12 08:22:15', '2022-10-12 08:22:15'),
(14, 15, '2022-10-12 08:22:15', '2022-10-12 08:22:15'),
(14, 16, '2022-10-12 08:22:15', '2022-10-12 08:22:15'),
(14, 17, '2022-10-12 08:22:15', '2022-10-12 08:22:15'),
(14, 18, '2022-10-12 08:22:15', '2022-10-12 08:22:15'),
(14, 19, '2022-10-12 08:22:15', '2022-10-12 08:22:15'),
(14, 20, '2022-10-12 08:22:15', '2022-10-12 08:22:15'),
(14, 21, '2022-10-12 08:22:15', '2022-10-12 08:22:15'),
(14, 22, '2022-10-12 08:22:15', '2022-10-12 08:22:15'),
(15, 1, '2022-10-12 13:47:05', '2022-10-12 13:47:05'),
(15, 3, '2022-10-12 13:47:05', '2022-10-12 13:47:05'),
(15, 2, '2022-10-12 13:47:05', '2022-10-12 13:47:05'),
(15, 4, '2022-10-12 13:47:05', '2022-10-12 13:47:05'),
(15, 5, '2022-10-12 13:47:05', '2022-10-12 13:47:05'),
(15, 6, '2022-10-12 13:47:05', '2022-10-12 13:47:05'),
(15, 7, '2022-10-12 13:47:05', '2022-10-12 13:47:05'),
(15, 8, '2022-10-12 13:47:05', '2022-10-12 13:47:05'),
(15, 9, '2022-10-12 13:47:05', '2022-10-12 13:47:05'),
(15, 10, '2022-10-12 13:47:05', '2022-10-12 13:47:05'),
(15, 11, '2022-10-12 13:47:05', '2022-10-12 13:47:05'),
(15, 12, '2022-10-12 13:47:05', '2022-10-12 13:47:05'),
(15, 13, '2022-10-12 13:47:05', '2022-10-12 13:47:05'),
(15, 14, '2022-10-12 13:47:05', '2022-10-12 13:47:05'),
(15, 15, '2022-10-12 13:47:05', '2022-10-12 13:47:05'),
(15, 16, '2022-10-12 13:47:05', '2022-10-12 13:47:05'),
(15, 17, '2022-10-12 13:47:05', '2022-10-12 13:47:05'),
(15, 18, '2022-10-12 13:47:05', '2022-10-12 13:47:05'),
(15, 19, '2022-10-12 13:47:05', '2022-10-12 13:47:05'),
(15, 20, '2022-10-12 13:47:05', '2022-10-12 13:47:05'),
(15, 21, '2022-10-12 13:47:05', '2022-10-12 13:47:05'),
(15, 22, '2022-10-12 13:47:05', '2022-10-12 13:47:05');
--
-- Base de données : `j_sentmail`
--
CREATE DATABASE IF NOT EXISTS `j_sentmail` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `j_sentmail`;

-- --------------------------------------------------------

--
-- Structure de la table `courriers`
--

DROP TABLE IF EXISTS `courriers`;
CREATE TABLE IF NOT EXISTS `courriers` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `courrier_libele` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `courrier_date_arrive` date NOT NULL,
  `courrier_status` enum('enStok','enCours','destoke') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `emeteur_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `emplacement_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `courriers_emeteur_id_foreign` (`emeteur_id`),
  KEY `courriers_user_id_foreign` (`user_id`),
  KEY `courriers_emplacement_id_foreign` (`emplacement_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `destinataires`
--

DROP TABLE IF EXISTS `destinataires`;
CREATE TABLE IF NOT EXISTS `destinataires` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `destinataire_noms` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `destinataire_prenoms` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `destinataire_email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `destinataire_telephone` int NOT NULL,
  `destinataire_pasword` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `emeteurs`
--

DROP TABLE IF EXISTS `emeteurs`;
CREATE TABLE IF NOT EXISTS `emeteurs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `emeteur_noms` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `emplacements`
--

DROP TABLE IF EXISTS `emplacements`;
CREATE TABLE IF NOT EXISTS `emplacements` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `emplacement_noms` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `emplacement_detail` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `historiques`
--

DROP TABLE IF EXISTS `historiques`;
CREATE TABLE IF NOT EXISTS `historiques` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `poste_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `historiques_poste_id_foreign` (`poste_id`),
  KEY `historiques_user_id_foreign` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `historiques`
--

INSERT INTO `historiques` (`id`, `poste_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2022-08-18 14:22:03', '2022-08-18 14:22:03');

-- --------------------------------------------------------

--
-- Structure de la table `images`
--

DROP TABLE IF EXISTS `images`;
CREATE TABLE IF NOT EXISTS `images` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `images` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `message`
--

DROP TABLE IF EXISTS `message`;
CREATE TABLE IF NOT EXISTS `message` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2022_06_16_105357_create_receptionistes_table', 1),
(5, '2022_06_16_114634_create_emplacements_table', 1),
(6, '2022_06_16_115737_create_destinataires_table', 1),
(7, '2022_06_16_121946_create_postes_table', 1),
(8, '2022_06_16_130707_create_historiques_table', 1),
(9, '2022_06_16_132853_create_emeteurs_table', 1),
(10, '2022_06_16_133129_create_courriers_table', 1),
(11, '2022_06_20_105740_create_roles_table', 1),
(12, '2022_06_24_082540_create_messages_table', 1),
(13, '2022_07_05_133006_create_notifications_table', 1),
(14, '2022_07_17_153444_create_images_table', 1),
(15, '2022_08_12_120856_userrole_table', 2),
(16, '2022_08_16_102418_permission_table', 2),
(17, '2022_08_16_102503_userpermission_table', 2),
(18, '2022_08_16_103713_user_permissions_table', 2),
(19, '2022_08_16_103910_permissions_table', 2);

-- --------------------------------------------------------

--
-- Structure de la table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint UNSIGNED NOT NULL,
  `data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
CREATE TABLE IF NOT EXISTS `permissions` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `permission_libele` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `permissions`
--

INSERT INTO `permissions` (`id`, `permission_libele`) VALUES
(1, 'ajouter les courriers'),
(2, 'modifier les courriers'),
(3, 'supprimer les courriers'),
(4, 'déstocker les courriers'),
(5, 'ajouter les emplacements'),
(6, 'modifier les emplacements'),
(7, 'ajouter les émetteurs'),
(8, 'modifier les émetteurs'),
(9, 'valider la réception des courriers'),
(10, 'voir les courriers'),
(11, 'consulter la liste des courriers'),
(12, 'consulter la liste des emplacements'),
(13, 'consulter la liste des émetteurs'),
(14, 'ajouter les utilisateurs'),
(15, 'afficher les utilisateurs'),
(16, 'consulter la liste des utilisateurs'),
(17, 'modifier le profil des utilisateurs');

-- --------------------------------------------------------

--
-- Structure de la table `photo`
--

DROP TABLE IF EXISTS `photo`;
CREATE TABLE IF NOT EXISTS `photo` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `fileTitle` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `postes`
--

DROP TABLE IF EXISTS `postes`;
CREATE TABLE IF NOT EXISTS `postes` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `poste_libele` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `postes_id_unique` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `postes`
--

INSERT INTO `postes` (`id`, `poste_libele`, `created_at`, `updated_at`) VALUES
(1, 'dircteur', '2022-08-18 14:22:03', '2022-08-18 14:22:03');

-- --------------------------------------------------------

--
-- Structure de la table `receptionistes`
--

DROP TABLE IF EXISTS `receptionistes`;
CREATE TABLE IF NOT EXISTS `receptionistes` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `receptioniste_noms` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `receptioniste_prenoms` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `receptioniste_email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `receptioniste_password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `roles`
--

INSERT INTO `roles` (`id`, `first_name`, `last_name`) VALUES
(1, 'admin', '');

-- --------------------------------------------------------

--
-- Structure de la table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(191) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_agent` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `payload` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('5Ins61E4y7QGAWtzRDs1D3OfzOkqXDIDfzYRRmij', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiMHh0MVQ0QzdtaTh4VW9GbVo5Nzg4TlB2dEtGalZRN0o5dWIzMnlhYyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzY6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9jb3Vycmllci1pbmRleCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7fQ==', 1660838309);

-- --------------------------------------------------------

--
-- Structure de la table `userrole`
--

DROP TABLE IF EXISTS `userrole`;
CREATE TABLE IF NOT EXISTS `userrole` (
  `user_id` bigint UNSIGNED NOT NULL,
  `role_id` bigint UNSIGNED NOT NULL,
  KEY `userrole_user_id_foreign` (`user_id`),
  KEY `userrole_role_id_foreign` (`role_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `userrole`
--

INSERT INTO `userrole` (`user_id`, `role_id`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_id` bigint UNSIGNED DEFAULT NULL,
  `password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_type` enum('admin','user') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `age` tinyint NOT NULL DEFAULT '1',
  `address` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `utype` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT 'ADM for Admin and USR for user or Customer',
  `number` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ZIP` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `role_id` bigint UNSIGNED NOT NULL DEFAULT '1',
  `status` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT 'status',
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_remember_token_unique` (`remember_token`),
  KEY `users_image_id_foreign` (`image_id`),
  KEY `users_role_id_foreign` (`role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `gender`, `email`, `image_id`, `password`, `user_type`, `age`, `address`, `utype`, `number`, `city`, `ZIP`, `email_verified_at`, `role_id`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'dubel ', 'nguemle', NULL, 'dubelnguemle@gmail.com', NULL, '$2y$10$BuIGKalAOjfUfFrKHju6M.V6P8PaxdTaLUJFykgVvojILQM2yA6WO', 'user', 1, NULL, '1', NULL, NULL, NULL, NULL, 1, '1', NULL, '2022-08-18 14:22:03', '2022-08-18 14:22:03');

-- --------------------------------------------------------

--
-- Structure de la table `user_permissions`
--

DROP TABLE IF EXISTS `user_permissions`;
CREATE TABLE IF NOT EXISTS `user_permissions` (
  `user_id` bigint UNSIGNED NOT NULL,
  `permission_id` bigint UNSIGNED NOT NULL,
  KEY `user_permissions_user_id_foreign` (`user_id`),
  KEY `user_permissions_user_permission_id_foreign` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
--
-- Base de données : `laravel_app`
--
CREATE DATABASE IF NOT EXISTS `laravel_app` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `laravel_app`;

-- --------------------------------------------------------

--
-- Structure de la table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1);

-- --------------------------------------------------------

--
-- Structure de la table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
--
-- Base de données : `laravel_jwt`
--
CREATE DATABASE IF NOT EXISTS `laravel_jwt` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `laravel_jwt`;

-- --------------------------------------------------------

--
-- Structure de la table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1);

-- --------------------------------------------------------

--
-- Structure de la table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
--
-- Base de données : `line`
--
CREATE DATABASE IF NOT EXISTS `line` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `line`;

-- --------------------------------------------------------

--
-- Structure de la table `courriers`
--

DROP TABLE IF EXISTS `courriers`;
CREATE TABLE IF NOT EXISTS `courriers` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `courrier_libele` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `courrier_date_arrive` date NOT NULL,
  `courrier_status` enum('enStok','enCours','destoke') COLLATE utf8mb4_unicode_ci NOT NULL,
  `emeteur_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `emplacement_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `courriers_emeteur_id_foreign` (`emeteur_id`),
  KEY `courriers_user_id_foreign` (`user_id`),
  KEY `courriers_emplacement_id_foreign` (`emplacement_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `destinataires`
--

DROP TABLE IF EXISTS `destinataires`;
CREATE TABLE IF NOT EXISTS `destinataires` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `destinataire_noms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `destinataire_prenoms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `destinataire_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `destinataire_telephone` int NOT NULL,
  `destinataire_pasword` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `emeteurs`
--

DROP TABLE IF EXISTS `emeteurs`;
CREATE TABLE IF NOT EXISTS `emeteurs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `emeteur_noms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `emplacements`
--

DROP TABLE IF EXISTS `emplacements`;
CREATE TABLE IF NOT EXISTS `emplacements` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `emplacement_noms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emplacement_detail` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `historiques`
--

DROP TABLE IF EXISTS `historiques`;
CREATE TABLE IF NOT EXISTS `historiques` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `poste_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `historiques_poste_id_foreign` (`poste_id`),
  KEY `historiques_user_id_foreign` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `historiques`
--

INSERT INTO `historiques` (`id`, `poste_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2022-10-12 08:07:06', '2022-10-12 08:07:06'),
(2, 2, 2, '2022-10-12 08:07:30', '2022-10-12 08:07:30');

-- --------------------------------------------------------

--
-- Structure de la table `images`
--

DROP TABLE IF EXISTS `images`;
CREATE TABLE IF NOT EXISTS `images` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `images` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `message`
--

DROP TABLE IF EXISTS `message`;
CREATE TABLE IF NOT EXISTS `message` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2022_06_16_105357_create_receptionistes_table', 1),
(5, '2022_06_16_114634_create_emplacements_table', 1),
(6, '2022_06_16_115737_create_destinataires_table', 1),
(7, '2022_06_16_121946_create_postes_table', 1),
(8, '2022_06_16_130707_create_historiques_table', 1),
(9, '2022_06_16_132853_create_emeteurs_table', 1),
(10, '2022_06_16_133129_create_courriers_table', 1),
(11, '2022_06_20_105740_create_roles_table', 1),
(12, '2022_06_24_082540_create_messages_table', 1),
(13, '2022_07_05_133006_create_notifications_table', 1),
(14, '2022_07_17_153444_create_images_table', 1);

-- --------------------------------------------------------

--
-- Structure de la table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint UNSIGNED NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `postes`
--

DROP TABLE IF EXISTS `postes`;
CREATE TABLE IF NOT EXISTS `postes` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `poste_libele` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `postes_id_unique` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `postes`
--

INSERT INTO `postes` (`id`, `poste_libele`, `created_at`, `updated_at`) VALUES
(1, 'pdg', '2022-10-12 08:07:06', '2022-10-12 08:07:06'),
(2, 'pdg', '2022-10-12 08:07:30', '2022-10-12 08:07:30');

-- --------------------------------------------------------

--
-- Structure de la table `receptionistes`
--

DROP TABLE IF EXISTS `receptionistes`;
CREATE TABLE IF NOT EXISTS `receptionistes` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `receptioniste_noms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receptioniste_prenoms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receptioniste_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receptioniste_password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_id` bigint UNSIGNED DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_type` enum('admin','user') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `age` tinyint NOT NULL DEFAULT '1',
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `utype` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT 'ADM for Admin and USR for user or Customer',
  `number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ZIP` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `role_id` bigint UNSIGNED NOT NULL DEFAULT '1',
  `status` enum('actif','inactif') COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_remember_token_unique` (`remember_token`),
  KEY `users_image_id_foreign` (`image_id`),
  KEY `users_role_id_foreign` (`role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `gender`, `email`, `image_id`, `password`, `user_type`, `age`, `address`, `utype`, `number`, `city`, `ZIP`, `email_verified_at`, `role_id`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'abdou', 'maeva', NULL, 'chirac@gmail.com', NULL, '$2y$10$6mpn/maPqdCqCZXKJl0Xy.flZmXXpNHJt6AcA3VLEcD4TIzCqjeTS', 'user', 1, NULL, '1', NULL, NULL, NULL, NULL, 1, 'actif', NULL, '2022-10-12 08:07:06', '2022-10-12 08:07:06'),
(2, 'abdou', 'maeva', NULL, 'njutapmvouiabdouchirac@gmail.com', NULL, '$2y$10$9Yw9qSeIHjqTH.VT00yqvORZQBOKMzilMrfgo8wKCI3OMcdDPe72K', 'user', 1, NULL, '1', NULL, NULL, NULL, NULL, 1, 'actif', NULL, '2022-10-12 08:07:26', '2022-10-12 08:07:26');
--
-- Base de données : `livewire_multiple_image_upload`
--
CREATE DATABASE IF NOT EXISTS `livewire_multiple_image_upload` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `livewire_multiple_image_upload`;

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
--
-- Base de données : `location`
--
CREATE DATABASE IF NOT EXISTS `location` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `location`;

-- --------------------------------------------------------

--
-- Structure de la table `articles`
--

DROP TABLE IF EXISTS `articles`;
CREATE TABLE IF NOT EXISTS `articles` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `noSerie` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `imageUrl` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estDisponible` tinyint(1) NOT NULL DEFAULT '1',
  `type_article_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `articles_nom_unique` (`nom`),
  UNIQUE KEY `articles_noserie_unique` (`noSerie`),
  KEY `articles_type_article_id_foreign` (`type_article_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `article_location`
--

DROP TABLE IF EXISTS `article_location`;
CREATE TABLE IF NOT EXISTS `article_location` (
  `article_id` bigint UNSIGNED NOT NULL,
  `location_id` bigint UNSIGNED NOT NULL,
  KEY `article_location_article_id_foreign` (`article_id`),
  KEY `article_location_location_id_foreign` (`location_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `article_propriete`
--

DROP TABLE IF EXISTS `article_propriete`;
CREATE TABLE IF NOT EXISTS `article_propriete` (
  `article_id` bigint UNSIGNED NOT NULL,
  `propriete_article_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `article_propriete_article_id_foreign` (`article_id`),
  KEY `article_propriete_propriete_article_id_foreign` (`propriete_article_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `clients`
--

DROP TABLE IF EXISTS `clients`;
CREATE TABLE IF NOT EXISTS `clients` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prenom` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sexe` char(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dateNaissance` date NOT NULL,
  `lieuNaissance` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nationalite` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ville` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pays` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adresse` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telephone1` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telephone2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pieceIdentite` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `noPieceIdentite` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `duree_locations`
--

DROP TABLE IF EXISTS `duree_locations`;
CREATE TABLE IF NOT EXISTS `duree_locations` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `libelle` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valeurEnHeure` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `locations`
--

DROP TABLE IF EXISTS `locations`;
CREATE TABLE IF NOT EXISTS `locations` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `dateDebut` datetime NOT NULL,
  `dateFin` datetime NOT NULL,
  `client_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `statut_location_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `locations_client_id_foreign` (`client_id`),
  KEY `locations_user_id_foreign` (`user_id`),
  KEY `locations_statut_location_id_foreign` (`statut_location_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2022_07_13_101452_create_articles_table', 1),
(6, '2022_07_13_102222_create_type_articles_table', 1),
(7, '2022_07_13_102720_create_propriete_articles_table', 1),
(8, '2022_07_13_103347_create_permissions_table', 1),
(9, '2022_07_13_103810_create_statut_locations_table', 1),
(10, '2022_07_13_104012_create_locations_table', 1),
(11, '2022_07_13_105219_create_roles_table', 1),
(12, '2022_07_13_105347_create_paiements_table', 1),
(13, '2022_07_13_112757_create_clients_table', 1),
(14, '2022_07_13_113300_create_duree_locations_table', 1),
(15, '2022_07_13_113645_create_tarifications_table', 1),
(16, '2022_07_13_115714_create_article_location_table', 1),
(17, '2022_07_13_130947_create_user_role_table', 1),
(18, '2022_07_13_131114_create_user_permission_table', 1),
(19, '2022_07_13_131407_create_article_propriete_table', 1);

-- --------------------------------------------------------

--
-- Structure de la table `paiements`
--

DROP TABLE IF EXISTS `paiements`;
CREATE TABLE IF NOT EXISTS `paiements` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `montantPaye` double NOT NULL,
  `datePaiement` datetime NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `location_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `paiements_user_id_foreign` (`user_id`),
  KEY `paiements_location_id_foreign` (`location_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
CREATE TABLE IF NOT EXISTS `permissions` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `propriete_articles`
--

DROP TABLE IF EXISTS `propriete_articles`;
CREATE TABLE IF NOT EXISTS `propriete_articles` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `estObligatoire` tinyint(1) NOT NULL DEFAULT '1',
  `type_article_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `propriete_articles_nom_type_article_id_unique` (`nom`,`type_article_id`),
  KEY `propriete_articles_type_article_id_foreign` (`type_article_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `statut_locations`
--

DROP TABLE IF EXISTS `statut_locations`;
CREATE TABLE IF NOT EXISTS `statut_locations` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `tarifications`
--

DROP TABLE IF EXISTS `tarifications`;
CREATE TABLE IF NOT EXISTS `tarifications` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `prix` double NOT NULL,
  `duree_location_id` bigint UNSIGNED NOT NULL,
  `article_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tarifications_duree_location_id_article_id_unique` (`duree_location_id`,`article_id`),
  KEY `tarifications_article_id_foreign` (`article_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `type_articles`
--

DROP TABLE IF EXISTS `type_articles`;
CREATE TABLE IF NOT EXISTS `type_articles` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `type_articles_nom_unique` (`nom`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prenom` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sexe` char(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telephone1` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telephone2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pieceIdentite` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `numeroPieceIdentite` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `user_permission`
--

DROP TABLE IF EXISTS `user_permission`;
CREATE TABLE IF NOT EXISTS `user_permission` (
  `user_id` bigint UNSIGNED NOT NULL,
  `permission_id` bigint UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `user_role`
--

DROP TABLE IF EXISTS `user_role`;
CREATE TABLE IF NOT EXISTS `user_role` (
  `user_id` bigint UNSIGNED NOT NULL,
  `role_id` bigint UNSIGNED NOT NULL,
  KEY `user_role_user_id_foreign` (`user_id`),
  KEY `user_role_role_id_foreign` (`role_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
--
-- Base de données : `maeva`
--
CREATE DATABASE IF NOT EXISTS `maeva` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `maeva`;

-- --------------------------------------------------------

--
-- Structure de la table `courriers`
--

DROP TABLE IF EXISTS `courriers`;
CREATE TABLE IF NOT EXISTS `courriers` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `courrier_libele` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `courrier_date_arrive` date NOT NULL,
  `courrier_status` enum('enStok','enCours','destoke') COLLATE utf8mb4_unicode_ci NOT NULL,
  `emeteur_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `emplacement_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `courriers_emeteur_id_foreign` (`emeteur_id`),
  KEY `courriers_user_id_foreign` (`user_id`),
  KEY `courriers_emplacement_id_foreign` (`emplacement_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `destinataires`
--

DROP TABLE IF EXISTS `destinataires`;
CREATE TABLE IF NOT EXISTS `destinataires` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `destinataire_noms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `destinataire_prenoms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `destinataire_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `destinataire_telephone` int NOT NULL,
  `destinataire_pasword` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `emeteurs`
--

DROP TABLE IF EXISTS `emeteurs`;
CREATE TABLE IF NOT EXISTS `emeteurs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `emeteur_noms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `emplacements`
--

DROP TABLE IF EXISTS `emplacements`;
CREATE TABLE IF NOT EXISTS `emplacements` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `emplacement_noms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emplacement_detail` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `historiques`
--

DROP TABLE IF EXISTS `historiques`;
CREATE TABLE IF NOT EXISTS `historiques` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `historique_date_debut` date NOT NULL,
  `historique_date_fin` date NOT NULL,
  `poste_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `historiques_poste_id_foreign` (`poste_id`),
  KEY `historiques_user_id_foreign` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `message`
--

DROP TABLE IF EXISTS `message`;
CREATE TABLE IF NOT EXISTS `message` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2022_06_16_105357_create_receptionistes_table', 1),
(5, '2022_06_16_114634_create_emplacements_table', 1),
(6, '2022_06_16_115737_create_destinataires_table', 1),
(7, '2022_06_16_121946_create_postes_table', 1),
(8, '2022_06_16_130707_create_historiques_table', 1),
(9, '2022_06_16_132853_create_emeteurs_table', 1),
(10, '2022_06_16_133129_create_courriers_table', 1),
(11, '2022_06_20_105740_create_roles_table', 1),
(12, '2022_06_24_082540_create_messages_table', 1),
(13, '2022_07_05_133006_create_notifications_table', 1);

-- --------------------------------------------------------

--
-- Structure de la table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint UNSIGNED NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `postes`
--

DROP TABLE IF EXISTS `postes`;
CREATE TABLE IF NOT EXISTS `postes` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `receptionistes`
--

DROP TABLE IF EXISTS `receptionistes`;
CREATE TABLE IF NOT EXISTS `receptionistes` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `receptioniste_noms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receptioniste_prenoms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receptioniste_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receptioniste_password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_type` enum('admin','user') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `age` tinyint NOT NULL DEFAULT '1',
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `utype` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT 'ADM for Admin and USR for user or Customer',
  `number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ZIP` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `role_id` bigint UNSIGNED NOT NULL DEFAULT '1',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_remember_token_unique` (`remember_token`),
  KEY `users_role_id_foreign` (`role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `gender`, `email`, `password`, `user_type`, `age`, `address`, `utype`, `number`, `city`, `ZIP`, `email_verified_at`, `role_id`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'njoya', 'maeva', NULL, 'njutapmvouiabdouchirac@gmail.com', '$2y$10$7mLWttQXZbj72jEqy7cwm.R.rdvgcYIwYfEpqehWqEjLahgP2Zwqu', 'user', 1, NULL, '1', NULL, NULL, NULL, NULL, 1, NULL, '2022-08-18 06:46:45', '2022-08-18 06:46:45');
--
-- Base de données : `maman`
--
CREATE DATABASE IF NOT EXISTS `maman` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `maman`;

-- --------------------------------------------------------

--
-- Structure de la table `courriers`
--

DROP TABLE IF EXISTS `courriers`;
CREATE TABLE IF NOT EXISTS `courriers` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `courrier_libele` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `courrier_date_arrive` date NOT NULL,
  `courrier_status` enum('enStok','enCours','destoke') COLLATE utf8mb4_unicode_ci NOT NULL,
  `emeteur_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `emplacement_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `courriers_emeteur_id_foreign` (`emeteur_id`),
  KEY `courriers_user_id_foreign` (`user_id`),
  KEY `courriers_emplacement_id_foreign` (`emplacement_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `destinataires`
--

DROP TABLE IF EXISTS `destinataires`;
CREATE TABLE IF NOT EXISTS `destinataires` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `destinataire_noms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `destinataire_prenoms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `destinataire_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `destinataire_telephone` int NOT NULL,
  `destinataire_pasword` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `emeteurs`
--

DROP TABLE IF EXISTS `emeteurs`;
CREATE TABLE IF NOT EXISTS `emeteurs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `emeteur_noms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `emplacements`
--

DROP TABLE IF EXISTS `emplacements`;
CREATE TABLE IF NOT EXISTS `emplacements` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `emplacement_noms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emplacement_detail` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `historiques`
--

DROP TABLE IF EXISTS `historiques`;
CREATE TABLE IF NOT EXISTS `historiques` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `historique_date_debut` date NOT NULL,
  `historique_date_fin` date NOT NULL,
  `poste_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `historiques_poste_id_foreign` (`poste_id`),
  KEY `historiques_user_id_foreign` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `message`
--

DROP TABLE IF EXISTS `message`;
CREATE TABLE IF NOT EXISTS `message` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2022_06_16_105357_create_receptionistes_table', 1),
(5, '2022_06_16_114634_create_emplacements_table', 1),
(6, '2022_06_16_115737_create_destinataires_table', 1),
(7, '2022_06_16_121946_create_postes_table', 1),
(8, '2022_06_16_130707_create_historiques_table', 1),
(9, '2022_06_16_132853_create_emeteurs_table', 1),
(10, '2022_06_16_133129_create_courriers_table', 1),
(11, '2022_06_20_105740_create_roles_table', 1),
(12, '2022_06_24_082540_create_messages_table', 1);

-- --------------------------------------------------------

--
-- Structure de la table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `postes`
--

DROP TABLE IF EXISTS `postes`;
CREATE TABLE IF NOT EXISTS `postes` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `poste_libele` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `receptionistes`
--

DROP TABLE IF EXISTS `receptionistes`;
CREATE TABLE IF NOT EXISTS `receptionistes` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `receptioniste_noms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receptioniste_prenoms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receptioniste_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receptioniste_password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_destinataire` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_receptioniste` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `utype` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT 'ADM for Admin and USR for user or Customer',
  `number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ZIP` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `role_id` bigint UNSIGNED NOT NULL DEFAULT '1',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_id_unique` (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_remember_token_unique` (`remember_token`),
  KEY `users_role_id_foreign` (`role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `gender`, `email`, `password`, `utype`, `number`, `city`, `ZIP`, `email_verified_at`, `role_id`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'njoya', 'chirac', NULL, 'njoya@gmail.com', '$2y$10$OJeQ1B7iwCiiFcTTdHEOSObpP92CrQJ.alerxWUBJVo.rjGvnEGzy', '1', NULL, NULL, NULL, NULL, 1, 'X4zoPaCrssMUsdTi6HlkEhVMiwHvGXW35YWkHFpN9GfzQrK0S11rziWdXwIx', '2022-06-27 07:42:58', '2022-06-27 14:13:16'),
(2, 'njutpmvoui', 'abdou', NULL, 'njutapmvouiabdouchirac@gmail.com', '$2y$10$uVLoJ1sgy0Sh.cWmn.ex8.CMtE9RGdl7gftcaVuaP/lLa.VyZiVsG', '1', NULL, NULL, NULL, NULL, 1, 'lP79SyRazSUaDhQFOjAhO4xPUK2gprtPm56fFjg1NtZxjFWalSlEQJegCDLE', '2022-06-27 07:55:06', '2022-08-04 07:02:36'),
(3, 'f', 'g', NULL, 'abdou@gmail.com', '$2y$10$hpL4Hg3oy/S9/O6.W89q0u8VNwNMc44YEpYqWxdcyUlg7RvAFOUaK', '1', NULL, NULL, NULL, NULL, 1, 'HDBe3QM7No', '2022-07-22 05:36:13', '2022-07-22 05:36:13'),
(4, 'abdou', 'chirac', NULL, 'mimi@gmail.com', '$2y$10$3fq83OP8V.lMM4HmcOYTyO3lg1xm52/a14yd4gkgWuZl0TovYiiwC', '1', NULL, NULL, NULL, NULL, 1, 'HORuO7SfCW', '2022-07-22 06:25:07', '2022-07-22 06:25:07');
--
-- Base de données : `nanz`
--
CREATE DATABASE IF NOT EXISTS `nanz` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `nanz`;

-- --------------------------------------------------------

--
-- Structure de la table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2022_09_26_003804_create_postes_table', 1);

-- --------------------------------------------------------

--
-- Structure de la table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `postes`
--

DROP TABLE IF EXISTS `postes`;
CREATE TABLE IF NOT EXISTS `postes` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `poste_libele` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `postes`
--

INSERT INTO `postes` (`id`, `poste_libele`, `created_at`, `updated_at`) VALUES
(1, 'pdg', '2022-09-25 23:01:31', '2022-09-25 23:01:31'),
(2, 'sg', '2022-09-25 23:03:19', '2022-09-25 23:03:19'),
(3, 'dtgh', '2022-09-25 23:04:47', '2022-09-25 23:04:47'),
(4, 'dg', '2022-09-25 23:06:59', '2022-09-25 23:06:59'),
(5, 'p=permarnance , g =garde', '2022-09-26 11:43:01', '2022-09-26 11:43:01'),
(6, 'sf', '2022-09-26 11:43:54', '2022-09-26 11:43:54'),
(7, 'df', '2022-09-26 11:46:16', '2022-09-26 11:46:16');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `about` text COLLATE utf8mb4_unicode_ci,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `phone`, `location`, `about`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'abdou', 'njutapmvouiabdouchirac@gmail.com', NULL, NULL, NULL, NULL, '$2y$10$6BdAvLnHWa.xLDdekdIcmOf8ISzYBgdu1sAn5D/Sp2eevmsRh4U.e', NULL, '2022-09-25 22:56:40', '2022-09-25 22:56:40');
--
-- Base de données : `nouveau`
--
CREATE DATABASE IF NOT EXISTS `nouveau` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `nouveau`;

-- --------------------------------------------------------

--
-- Structure de la table `courriers`
--

DROP TABLE IF EXISTS `courriers`;
CREATE TABLE IF NOT EXISTS `courriers` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `courrier_libele` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `courrier_date_arrive` date NOT NULL,
  `courrier_status` enum('enStok','enCours','destoke') COLLATE utf8mb4_unicode_ci NOT NULL,
  `emeteur_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `emplacement_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `courriers_emeteur_id_foreign` (`emeteur_id`),
  KEY `courriers_user_id_foreign` (`user_id`),
  KEY `courriers_emplacement_id_foreign` (`emplacement_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `destinataires`
--

DROP TABLE IF EXISTS `destinataires`;
CREATE TABLE IF NOT EXISTS `destinataires` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `destinataire_noms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `destinataire_prenoms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `destinataire_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `destinataire_telephone` int NOT NULL,
  `destinataire_pasword` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `emeteurs`
--

DROP TABLE IF EXISTS `emeteurs`;
CREATE TABLE IF NOT EXISTS `emeteurs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `emeteur_noms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `emplacements`
--

DROP TABLE IF EXISTS `emplacements`;
CREATE TABLE IF NOT EXISTS `emplacements` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `emplacement_noms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emplacement_detail` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `historiques`
--

DROP TABLE IF EXISTS `historiques`;
CREATE TABLE IF NOT EXISTS `historiques` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `poste_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `historiques_id_unique` (`id`),
  KEY `historiques_poste_id_foreign` (`poste_id`),
  KEY `historiques_user_id_foreign` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `historiques`
--

INSERT INTO `historiques` (`id`, `poste_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2022-08-05 13:55:48', '2022-08-05 13:55:48');

-- --------------------------------------------------------

--
-- Structure de la table `images`
--

DROP TABLE IF EXISTS `images`;
CREATE TABLE IF NOT EXISTS `images` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `images`
--

INSERT INTO `images` (`id`, `image`, `created_at`, `updated_at`) VALUES
(1, '[\"images\\/7GoMsRtFqNyLPB0w3nsDoV1cPDR2xsFV5bl8Llza.jpg\"]', '2022-08-06 23:48:27', '2022-08-06 23:48:27'),
(2, '[\"images\\/kuyQuuPvh1SQL4gnVh4CogLKOeQg8NyYUi3EIdmb.jpg\"]', '2022-08-06 23:51:06', '2022-08-06 23:51:06'),
(3, '[\"images\\/dsEoY917YZMfhGyjSLAmV5wdOmsqAeA4r6N8bTm7.jpg\"]', '2022-08-06 23:57:43', '2022-08-06 23:57:43'),
(4, '[\"images\\/w4bmsL9Lt3J2zmqFssaV8AksHoj7yWT2UafB5AYN.jpg\"]', '2022-08-07 00:08:58', '2022-08-07 00:08:58'),
(5, '[\"images\\/XFda0qMFkjEm7NdkZe2wbURHS1VZPAbT24YzZqCG.jpg\"]', '2022-08-07 00:30:20', '2022-08-07 00:30:20');

-- --------------------------------------------------------

--
-- Structure de la table `message`
--

DROP TABLE IF EXISTS `message`;
CREATE TABLE IF NOT EXISTS `message` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2022_06_16_105357_create_receptionistes_table', 1),
(5, '2022_06_16_114634_create_emplacements_table', 1),
(6, '2022_06_16_115737_create_destinataires_table', 1),
(7, '2022_06_16_121946_create_postes_table', 1),
(8, '2022_06_16_130707_create_historiques_table', 1),
(9, '2022_06_16_132853_create_emeteurs_table', 1),
(10, '2022_06_16_133129_create_courriers_table', 1),
(11, '2022_06_20_105740_create_roles_table', 1),
(12, '2022_06_24_082540_create_messages_table', 1),
(13, '2022_07_05_133006_create_notifications_table', 1),
(14, '2022_07_12_102404_create_photos_table', 1),
(15, '2022_07_12_102931_create_photo_table', 1),
(16, '2022_07_17_153444_create_images_table', 1),
(17, '2022_07_26_114421_create_users_postes_table', 1);

-- --------------------------------------------------------

--
-- Structure de la table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint UNSIGNED NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `photo`
--

DROP TABLE IF EXISTS `photo`;
CREATE TABLE IF NOT EXISTS `photo` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `fileTitle` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `postes`
--

DROP TABLE IF EXISTS `postes`;
CREATE TABLE IF NOT EXISTS `postes` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `poste_libele` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `postes_id_unique` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `postes`
--

INSERT INTO `postes` (`id`, `poste_libele`, `created_at`, `updated_at`) VALUES
(1, 'pdg', '2022-08-05 13:55:48', '2022-08-05 13:55:48');

-- --------------------------------------------------------

--
-- Structure de la table `receptionistes`
--

DROP TABLE IF EXISTS `receptionistes`;
CREATE TABLE IF NOT EXISTS `receptionistes` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `receptioniste_noms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receptioniste_prenoms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receptioniste_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receptioniste_password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_type` enum('admin','user') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `age` tinyint NOT NULL DEFAULT '1',
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `utype` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT 'ADM for Admin and USR for user or Customer',
  `number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ZIP` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('actif','inactif') COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_id_unique` (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_remember_token_unique` (`remember_token`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `gender`, `email`, `password`, `user_type`, `age`, `address`, `utype`, `number`, `city`, `ZIP`, `status`, `email_verified_at`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'abdou', 'maeva', NULL, 'njutapmvouiabdouchirac@gmail.com', '$2y$10$1jgl7QyKY3WEssKK0o77bu7/d5eqYWoDzklBFcw0V/iXKqkGAqjZy', 'user', 1, NULL, '1', NULL, NULL, NULL, 'actif', NULL, NULL, '2022-08-05 13:55:48', '2022-08-05 13:55:48');

-- --------------------------------------------------------

--
-- Structure de la table `users_postes`
--

DROP TABLE IF EXISTS `users_postes`;
CREATE TABLE IF NOT EXISTS `users_postes` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `users_id` bigint UNSIGNED NOT NULL,
  `postes_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `users_postes_users_id_foreign` (`users_id`),
  KEY `users_postes_postes_id_foreign` (`postes_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
--
-- Base de données : `rahamanou`
--
CREATE DATABASE IF NOT EXISTS `rahamanou` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `rahamanou`;

-- --------------------------------------------------------

--
-- Structure de la table `employees`
--

DROP TABLE IF EXISTS `employees`;
CREATE TABLE IF NOT EXISTS `employees` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2022_08_09_083930_create_employees_table', 2);

-- --------------------------------------------------------

--
-- Structure de la table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
--
-- Base de données : `tchat`
--
CREATE DATABASE IF NOT EXISTS `tchat` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `tchat`;

-- --------------------------------------------------------

--
-- Structure de la table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1);

-- --------------------------------------------------------

--
-- Structure de la table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unique` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
--
-- Base de données : `vente_vehicul`
--
CREATE DATABASE IF NOT EXISTS `vente_vehicul` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `vente_vehicul`;

-- --------------------------------------------------------

--
-- Structure de la table `personne`
--

DROP TABLE IF EXISTS `personne`;
CREATE TABLE IF NOT EXISTS `personne` (
  `NumACH` int NOT NULL,
  `Nom` char(20) NOT NULL,
  `Ville` char(40) DEFAULT NULL,
  `AGE` int NOT NULL,
  PRIMARY KEY (`NumACH`)
) ;

-- --------------------------------------------------------

--
-- Structure de la table `voiture`
--

DROP TABLE IF EXISTS `voiture`;
CREATE TABLE IF NOT EXISTS `voiture` (
  `Numvoit` int NOT NULL,
  PRIMARY KEY (`Numvoit`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
--
-- Base de données : `zena`
--
CREATE DATABASE IF NOT EXISTS `zena` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `zena`;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
